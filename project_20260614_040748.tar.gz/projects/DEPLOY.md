# 未来鹅 - Vercel 部署指南

## 前提条件

1. 一个 [GitHub](https://github.com) 账号
2. 一个 [Vercel](https://vercel.com) 账号（可用 GitHub 登录，免费额度充足）

## 第一步：推送代码到 GitHub

```bash
# 1. 在 GitHub 上创建新仓库（不要勾选初始化 README）
# 2. 在本地项目目录执行：

git remote add origin https://github.com/<你的用户名>/<仓库名>.git
git branch -M main
git push -u origin main
```

## 第二步：在 Vercel 导入项目

1. 登录 [vercel.com](https://vercel.com)
2. 点击 **"Add New"** → **"Project"**
3. 选择 **"Import Git Repository"**
4. 找到你刚推送的 GitHub 仓库，点击 **"Import"**
5. Framework Preset 自动检测为 **Next.js**，保持默认即可
6. 点击 **"Environment Variables"** 展开，添加以下环境变量

## 第三步：配置环境变量（关键）

在 Vercel 的 Environment Variables 中添加以下变量：

### Coze API（核心，必填）

| 变量名 | 值 | 说明 |
|--------|-----|------|
| `COZE_WORKLOAD_API_TOKEN` | `pat_你的PAT` | 永久 API Token，从 [coze.cn/open/oauth/pats](https://www.coze.cn/open/oauth/pats) 获取 |
| `COZE_INTEGRATION_BASE_URL` | `https://api.coze.cn` | API 基础地址（注意不是 integration.coze.cn） |
| `COZE_PROJECT_SPACE_ID` | `7649028615350796322` | 工作空间 ID |

### Supabase（登录/个人中心，必填）

| 变量名 | 说明 | 获取方式 |
|--------|------|----------|
| `COZE_SUPABASE_URL` | Supabase 项目 URL | Supabase 控制台 → Settings → API → Project URL |
| `COZE_SUPABASE_ANON_KEY` | Supabase Anon Key | Supabase 控制台 → Settings → API → anon public |
| `COZE_SUPABASE_SERVICE_ROLE_KEY` | Supabase Service Role Key | Supabase 控制台 → Settings → API → service_role |

> ⚠️ `COZE_SUPABASE_SERVICE_ROLE_KEY` 拥有数据库完全访问权限，请勿泄露！

### Bot 配置（可选）

| 变量名 | 值 | 说明 |
|--------|-----|------|
| `NEXT_PUBLIC_BOT_ID` | `7650848876500860962` | 鹅小伴 Bot ID（用于 Coze Bot 对话模式） |

### PAT 权限配置

创建 PAT 时需勾选以下权限：
- ✅ `chat:write` — 发起对话（必填）
- ✅ `bot:read` — 读取 Bot 信息（推荐）
- ✅ `model:read` — 读取模型列表（推荐）
- ✅ `conversation:read` — 读取对话消息（推荐）

## 第四步：部署

1. 确认所有环境变量已添加
2. 点击 **"Deploy"**
3. 等待构建完成（约 1-2 分钟）
4. 部署成功后，Vercel 会分配一个 `xxx.vercel.app` 域名

## 自定义域名（可选）

1. Vercel 项目 → Settings → Domains
2. 添加你的自定义域名
3. 按提示配置 DNS 记录

## Vercel 免费额度

- 带宽：100GB/月
- Serverless 函数执行：1000万次/月
- 构建时长：6000分钟/月
- 对于个人项目完全够用

## 项目关键信息

| 信息 | 值 |
|------|-----|
| Bot ID | `7650848876500860962` |
| 空间 ID | `7649028615350796322` |
| Bot 名称 | 鹅小伴 |
| API Base | `https://api.coze.cn` |

## 常见问题

### Q: 为什么不能部署到 GitHub Pages？
A: 本项目使用 Next.js API Routes（7个后端接口），需要 Node.js 服务端运行，纯静态托管无法支持。

### Q: 部署后页面 500 怎么办？
A: 检查 Vercel 项目 → Settings → Environment Variables，确认所有变量正确配置。

### Q: 如何更新部署？
A: 推送代码到 GitHub 即可，Vercel 会自动重新部署。

### Q: PAT 在哪里获取？
A: 登录 [coze.cn](https://www.coze.cn) → 右上角头像 → API 令牌 → 创建个人访问令牌
