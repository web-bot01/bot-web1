import { pgTable, serial, timestamp, text, integer, jsonb } from "drizzle-orm/pg-core"
import { sql } from "drizzle-orm"



export const healthCheck = pgTable("health_check", {
	id: serial().notNull(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }).defaultNow(),
});

export const jobRecommendations = pgTable("job_recommendations", {
	id: serial().notNull(),
	userId: text("user_id").notNull().default(sql`auth.uid()`),
	jobTitle: text("job_title").notNull(),
	department: text(),
	matchScore: integer("match_score"),
	reason: text(),
	courseLink: text("course_link"),
	skills: text(),
	category: text(),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow(),
});

export const userProfiles = pgTable("user_profiles", {
	id: serial().notNull(),
	userId: text("user_id").notNull(),
	nickname: text(),
	grade: text(),
	interest: text(),
	currentStage: text("current_stage").default('探索期'),
	superPowers: text("super_powers"),
	achievements: text().default('🌱 初来乍到'),
	completedTasks: integer("completed_tasks").default(0),
	roundtableCount: integer("roundtable_count").default(0),
	letterCount: integer("letter_count").default(0),
	assessmentResult: jsonb("assessment_result"),
	growthPlan: jsonb("growth_plan"),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow(),
	updatedAt: timestamp("updated_at", { withTimezone: true, mode: 'string' }).defaultNow(),
});

export const achievementDefinitions = pgTable("achievement_definitions", {
	id: serial().notNull(),
	code: text().notNull().unique(),
	emoji: text().notNull(),
	name: text().notNull(),
	description: text().notNull(),
	category: text().notNull().default('growth'),
	conditionType: text("condition_type").notNull(),
	conditionValue: integer("condition_value").notNull().default(1),
	sortOrder: integer("sort_order").notNull().default(0),
	createdAt: timestamp("created_at", { withTimezone: true, mode: 'string' }).defaultNow(),
});

export const userAchievements = pgTable("user_achievements", {
	id: serial().notNull(),
	userId: text("user_id").notNull(),
	achievementCode: text("achievement_code").notNull(),
	unlockedAt: timestamp("unlocked_at", { withTimezone: true, mode: 'string' }).defaultNow(),
});
