'use client';

import { useState, useEffect, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import { useSupabaseConfig } from '@/lib/supabase-config-inject';
import { getSupabaseBrowserClientWithRetry } from '@/lib/supabase-browser';

interface UserProfile {
  id: string;
  user_id: string;
  nickname: string;
  grade: string;
  interest: string;
  achievements: string;
  super_powers: string;
  completed_tasks: number;
  roundtable_count: number;
  letter_count: number;
  current_stage: string;
  assessment_result: Record<string, unknown> | null;
  growth_plan: Record<string, unknown> | null;
  created_at: string;
  updated_at: string;
}

interface Achievement {
  code: string;
  emoji: string;
  name: string;
  description: string;
  category: string;
  conditionType: string;
  conditionValue: number;
  unlocked: boolean;
  progress: number;
}

interface GrowthDimension {
  key: string;
  label: string;
  maxProgress: number;
  description: string;
  progress: number;
  percentage: number;
}

export default function ProfilePage() {
  const router = useRouter();
  const { config } = useSupabaseConfig();
  const [user, setUser] = useState<{ id: string; email: string } | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [editing, setEditing] = useState(false);
  const [editForm, setEditForm] = useState({ nickname: '', grade: '', interest: '' });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [growthDimensions, setGrowthDimensions] = useState<GrowthDimension[]>([]);
  const [growthLevel, setGrowthLevel] = useState({ level: 1, name: '萌芽期' });

  const fetchProfile = useCallback(async () => {
    if (!config) { setLoading(false); return; }
    try {
      const supabase = await getSupabaseBrowserClientWithRetry();
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) { router.push('/login'); return; }
      setUser({ id: session.user.id, email: session.user.email ?? '' });

      const headers = { 'x-session': session.access_token };

      // Fetch profile
      const res = await fetch('/api/profile', { headers });
      if (res.ok) {
        const data = await res.json();
        setProfile(data.profile || data);
        const p = data.profile || data;
        setEditForm({ nickname: p.nickname || '', grade: p.grade || '', interest: p.interest || '' });
      }

      // Fetch achievements (check + unlock new ones)
      const achRes = await fetch('/api/achievements', { headers });
      if (achRes.ok) {
        const achData = await achRes.json();
        setAchievements(achData.achievements || []);
      }

      // Trigger achievement unlock check
      await fetch('/api/achievements', { method: 'POST', headers });

      // Re-fetch achievements after unlock check
      const achRes2 = await fetch('/api/achievements', { headers });
      if (achRes2.ok) {
        const achData2 = await achRes2.json();
        setAchievements(achData2.achievements || []);
      }

      // Fetch growth progress
      const gpRes = await fetch('/api/growth-progress', { headers });
      if (gpRes.ok) {
        const gpData = await gpRes.json();
        setGrowthDimensions(gpData.dimensions || []);
        if (gpData.level) {
          setGrowthLevel({ level: gpData.level.level, name: gpData.level.name });
        }
      }
    } catch {
      // Config not ready or fetch failed
    }
    setLoading(false);
  }, [router, config]);

  useEffect(() => { fetchProfile(); }, [fetchProfile]);

  const handleSave = async () => {
    if (!user) return;
    setSaving(true);
    try {
      const supabase = await getSupabaseBrowserClientWithRetry();
      const { data: { session } } = await supabase.auth.getSession();
      await fetch('/api/profile', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json', 'x-session': session?.access_token ?? '' },
        body: JSON.stringify(editForm),
      });
      setEditing(false);
      fetchProfile();
    } catch {
      // Save failed
    }
    setSaving(false);
  };

  const handleLogout = async () => {
    try {
      const supabase = await getSupabaseBrowserClientWithRetry();
      await supabase.auth.signOut();
    } catch {
      // Sign out failed
    }
    router.push('/login');
  };

  if (!config) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-white to-teal-50">
        <nav className="bg-gradient-to-r from-emerald-500 to-emerald-600 text-white px-4 py-3 flex items-center gap-3 sticky top-0 z-10">
          <button onClick={() => router.push('/')} className="p-1 hover:bg-white/20 rounded-lg transition-colors">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" /></svg>
          </button>
          <h1 className="font-bold">个人中心</h1>
        </nav>
        <div className="max-w-md mx-auto mt-20 text-center px-4">
          <div className="text-5xl mb-4">🔧</div>
          <h2 className="text-xl font-bold text-gray-800 mb-2">登录功能配置中</h2>
          <p className="text-sm text-gray-500 mb-6">
            个人中心需要登录后使用，登录服务正在配置中，请稍后再来。
          </p>
          <button
            onClick={() => router.push('/')}
            className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-emerald-600 text-white font-medium hover:from-emerald-600 hover:to-emerald-700 transition-all shadow-md"
          >
            返回首页
          </button>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-emerald-500 animate-pulse text-lg">加载中...</div>
      </div>
    );
  }

  const grades = ['大一', '大二', '大三', '大四', '研一', '研二', '研三', '已毕业'];
  const stageLabels: Record<string, string> = { explore: '探索期', '探索期': '探索期', prepare: '准备期', '准备期': '准备期', sprint: '冲刺期', '冲刺期': '冲刺期', review: '复盘期', '复盘期': '复盘期' };
  const stageColors: Record<string, string> = { explore: 'bg-emerald-100 text-emerald-700', '探索期': 'bg-emerald-100 text-emerald-700', prepare: 'bg-blue-100 text-blue-700', '准备期': 'bg-blue-100 text-blue-700', sprint: 'bg-orange-100 text-orange-700', '冲刺期': 'bg-orange-100 text-orange-700', review: 'bg-purple-100 text-purple-700', '复盘期': 'bg-purple-100 text-purple-700' };
  const currentStage = profile?.current_stage || '探索期';

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-white to-teal-50">
      {/* Top Nav */}
      <nav className="bg-gradient-to-r from-emerald-500 to-emerald-600 text-white px-4 py-3 flex items-center gap-3 sticky top-0 z-10">
        <button onClick={() => router.push('/')} className="p-1 hover:bg-white/20 rounded-lg transition-colors">
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" /></svg>
        </button>
        <h1 className="font-bold">个人中心</h1>
      </nav>

      <div className="max-w-2xl mx-auto p-4 space-y-4">
        {/* Profile Header Card */}
        <div className="bg-gradient-to-br from-emerald-600 to-emerald-700 rounded-2xl p-6 text-white">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-full bg-white/20 flex items-center justify-center text-3xl">🐧</div>
            <div className="flex-1">
              <h2 className="text-xl font-bold">{profile?.nickname || '未设置昵称'}</h2>
              <p className="text-emerald-100 text-sm">{user?.email}</p>
              <div className="flex items-center gap-2 mt-1">
                <span className="text-xs px-2 py-0.5 rounded-full bg-white/20">{profile?.grade || '未设置年级'}</span>
                <span className={`text-xs px-2 py-0.5 rounded-full ${stageColors[currentStage] || 'bg-emerald-100 text-emerald-700'}`}>
                  {stageLabels[currentStage] || currentStage}
                </span>
              </div>
            </div>
            <button
              onClick={() => setEditing(true)}
              className="p-2 rounded-xl bg-white/20 hover:bg-white/30 transition-colors"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" /></svg>
            </button>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-4 gap-3">
          {[
            { label: '探索任务', value: profile?.completed_tasks ?? 0, icon: '🎯', color: 'text-emerald-600' },
            { label: '圆桌参与', value: profile?.roundtable_count ?? 0, icon: '🎤', color: 'text-blue-600' },
            { label: '收到回信', value: profile?.letter_count ?? 0, icon: '💌', color: 'text-pink-600' },
            { label: '已解锁成就', value: achievements.filter(a => a.unlocked).length, icon: '🏅', color: 'text-amber-600' },
          ].map((stat) => (
            <div key={stat.label} className="bg-white rounded-xl p-3 text-center shadow-sm border border-gray-100">
              <div className="text-xl mb-1">{stat.icon}</div>
              <div className={`text-lg font-bold ${stat.color}`}>{stat.value}</div>
              <div className="text-xs text-gray-500">{stat.label}</div>
            </div>
          ))}
        </div>

        {/* Growth Progress */}
        {growthDimensions.length > 0 && (
          <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-bold text-gray-800">📈 成长进度</h3>
              <span className="text-xs bg-emerald-50 text-emerald-600 px-2.5 py-1 rounded-full font-medium">
                Lv.{growthLevel.level} {growthLevel.name}
              </span>
            </div>
            <div className="space-y-3">
              {growthDimensions.map((dim) => {
                const colors: Record<string, string> = {
                  direction: 'bg-emerald-400',
                  work: 'bg-amber-400',
                  roundtable: 'bg-blue-400',
                  interview: 'bg-purple-400',
                };
                return (
                  <div key={dim.key}>
                    <div className="flex justify-between text-xs mb-1">
                      <span className="text-gray-600">{dim.label}</span>
                      <span className="text-gray-400">{dim.progress}/{dim.maxProgress}</span>
                    </div>
                    <div className="h-2.5 bg-gray-100 rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-500 ${colors[dim.key] || 'bg-gray-300'}`}
                        style={{ width: `${Math.min(dim.percentage, 100)}%` }}
                      />
                    </div>
                    <p className="text-xs text-gray-400 mt-0.5">{dim.description}</p>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* My Planet */}
        <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-bold text-gray-800">🪐 我的星球</h3>
            <button
              onClick={() => router.push('/jobs')}
              className="text-sm text-emerald-600 hover:text-emerald-700 font-medium"
            >
              查看岗位推荐 →
            </button>
          </div>
          <div className="bg-gradient-to-br from-emerald-50 to-teal-50 rounded-xl p-4">
            <div className="text-center mb-3">
              <span className="text-4xl">🌍</span>
              <p className="font-bold text-emerald-700 mt-1">{profile?.nickname || '我的'}的星球</p>
              <p className="text-sm text-emerald-600">正在发光中 ✨</p>
            </div>
            <div className="grid grid-cols-2 gap-2 text-sm">
              <div className="bg-white/80 rounded-lg p-2 text-center">
                <span className="text-gray-500">探索方向</span>
                <p className="font-medium text-gray-800">{profile?.interest || '待探索'}</p>
              </div>
              <div className="bg-white/80 rounded-lg p-2 text-center">
                <span className="text-gray-500">当前阶段</span>
                <p className="font-medium text-gray-800">{stageLabels[currentStage] || currentStage}</p>
              </div>
            </div>
            {profile?.super_powers && (
              <div className="mt-3 flex flex-wrap gap-1.5 justify-center">
                {profile.super_powers.split(',').filter(Boolean).map((sp: string) => (
                  <span key={sp} className="px-2.5 py-1 rounded-full bg-blue-100 text-blue-700 text-xs font-medium">{sp}</span>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Achievements */}
        <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-bold text-gray-800">🏅 成就墙</h3>
            <span className="text-xs text-gray-400">{achievements.filter(a => a.unlocked).length}/{achievements.length} 已解锁</span>
          </div>
          {achievements.length > 0 ? (
            <div className="grid grid-cols-4 gap-3">
              {achievements.map((badge) => {
                const progressPct = Math.min(Math.round((badge.progress / badge.conditionValue) * 100), 100);
                return (
                  <div key={badge.code} className="text-center group relative">
                    <div className={`w-14 h-14 mx-auto rounded-xl flex items-center justify-center text-2xl transition-all duration-200 ${
                      badge.unlocked
                        ? 'bg-gradient-to-br from-amber-50 to-yellow-50 shadow-sm ring-2 ring-amber-200/50'
                        : 'bg-gray-50 opacity-40 grayscale'
                    }`}>
                      {badge.emoji}
                    </div>
                    <p className={`text-xs mt-1.5 font-medium ${badge.unlocked ? 'text-gray-700' : 'text-gray-400'}`}>
                      {badge.name}
                    </p>
                    {!badge.unlocked && badge.progress > 0 && (
                      <div className="mt-1 h-1 bg-gray-100 rounded-full overflow-hidden">
                        <div className="h-full bg-amber-300 rounded-full" style={{ width: `${progressPct}%` }} />
                      </div>
                    )}
                    {/* Tooltip */}
                    <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 hidden group-hover:block z-10 w-28">
                      <div className="bg-gray-800 text-white text-xs rounded-lg p-2 text-center shadow-lg">
                        <p className="font-medium">{badge.name}</p>
                        <p className="text-gray-300 mt-0.5">{badge.description}</p>
                        {!badge.unlocked && (
                          <p className="text-amber-300 mt-0.5">{badge.progress}/{badge.conditionValue}</p>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="text-center py-8 text-gray-400">
              <div className="text-4xl mb-2">🏅</div>
              <p className="text-sm">完成更多任务来解锁成就吧</p>
            </div>
          )}
        </div>

        {/* Quick Links */}
        <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
          <h3 className="font-bold text-gray-800 mb-3">⚡ 快捷入口</h3>
          <div className="grid grid-cols-2 gap-3">
            {[
              { icon: '🎯', label: '岗位推荐', href: '/jobs' },
              { icon: '📋', label: '职业测评', href: '/' },
              { icon: '💬', label: 'AI对话', href: '/' },
              { icon: '📈', label: '成长规划', href: '/' },
            ].map((link) => (
              <button
                key={link.label}
                onClick={() => router.push(link.href)}
                className="flex items-center gap-3 p-3 rounded-xl border border-gray-100 hover:border-emerald-200 hover:bg-emerald-50 transition-all"
              >
                <span className="text-2xl">{link.icon}</span>
                <span className="font-medium text-gray-700">{link.label}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Logout */}
        <button
          onClick={() => setShowLogoutConfirm(true)}
          className="w-full py-3 rounded-xl border border-red-200 text-red-500 font-medium hover:bg-red-50 transition-colors"
        >
          退出登录
        </button>
      </div>

      {/* Edit Modal */}
      {editing && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl p-6 w-full max-w-md">
            <h3 className="font-bold text-lg mb-4">编辑个人信息</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">昵称</label>
                <input
                  type="text"
                  value={editForm.nickname}
                  onChange={(e) => setEditForm({ ...editForm, nickname: e.target.value })}
                  className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none text-sm"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">年级</label>
                <select
                  value={editForm.grade}
                  onChange={(e) => setEditForm({ ...editForm, grade: e.target.value })}
                  className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-emerald-500 outline-none text-sm"
                >
                  <option value="">请选择</option>
                  {grades.map((g) => <option key={g} value={g}>{g}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">职业兴趣</label>
                <input
                  type="text"
                  value={editForm.interest}
                  onChange={(e) => setEditForm({ ...editForm, interest: e.target.value })}
                  placeholder="如：产品经理、前端开发..."
                  className="w-full px-4 py-2.5 rounded-xl border border-gray-200 focus:border-emerald-500 focus:ring-2 focus:ring-emerald-200 outline-none text-sm"
                />
              </div>
            </div>
            <div className="flex gap-3 mt-6">
              <button
                onClick={() => setEditing(false)}
                className="flex-1 py-2.5 rounded-xl border border-gray-200 text-gray-600 font-medium hover:bg-gray-50 transition-colors"
              >
                取消
              </button>
              <button
                onClick={handleSave}
                disabled={saving}
                className="flex-1 py-2.5 rounded-xl bg-emerald-500 text-white font-medium hover:bg-emerald-600 transition-colors disabled:opacity-50"
              >
                {saving ? '保存中...' : '保存'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Logout Confirm Modal */}
      {showLogoutConfirm && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl p-6 w-full max-w-sm text-center">
            <div className="text-4xl mb-3">👋</div>
            <h3 className="font-bold text-lg mb-2">确认退出登录？</h3>
            <p className="text-sm text-gray-500 mb-6">退出后需要重新登录才能使用个人中心功能</p>
            <div className="flex gap-3">
              <button
                onClick={() => setShowLogoutConfirm(false)}
                className="flex-1 py-2.5 rounded-xl border border-gray-200 text-gray-600 font-medium hover:bg-gray-50 transition-colors"
              >
                取消
              </button>
              <button
                onClick={handleLogout}
                className="flex-1 py-2.5 rounded-xl bg-red-500 text-white font-medium hover:bg-red-600 transition-colors"
              >
                退出
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
