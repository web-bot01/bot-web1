import { NextRequest, NextResponse } from "next/server"
import { getSupabaseClient } from "@/storage/database/supabase-client"

// 成长维度定义
const GROWTH_DIMENSIONS = [
  { key: "direction", label: "方向探索", maxProgress: 3, description: "确定职业方向" },
  { key: "work", label: "作品产出", maxProgress: 3, description: "完成探索任务产出作品" },
  { key: "roundtable", label: "圆桌参与", maxProgress: 2, description: "参与行业圆桌讨论" },
  { key: "interview", label: "面试准备", maxProgress: 3, description: "准备面试和求职材料" },
]

// 成长等级定义
const LEVELS = [
  { level: 1, name: "萌芽期", minExp: 0 },
  { level: 2, name: "生长期", minExp: 4 },
  { level: 3, name: "拔节期", minExp: 8 },
  { level: 4, name: "开花期", minExp: 12 },
  { level: 5, name: "结果期", minExp: 16 },
]

function calculateLevel(totalProgress: number) {
  let current = LEVELS[0]
  let next: typeof LEVELS[number] | null = null
  for (const lvl of LEVELS) {
    if (totalProgress >= lvl.minExp) {
      current = lvl
      const idx = LEVELS.indexOf(lvl)
      next = idx < LEVELS.length - 1 ? LEVELS[idx + 1] : null
    }
  }
  return {
    level: current.level,
    name: current.name,
    exp: totalProgress,
    expToNext: next ? next.minExp - current.minExp : 0,
    expInLevel: totalProgress - current.minExp,
  }
}

// GET /api/growth-progress - 获取成长进度
export async function GET(request: NextRequest) {
  const sessionToken = request.headers.get("x-session")

  // 无登录时返回默认进度
  if (!sessionToken) {
    const defaultDimensions = GROWTH_DIMENSIONS.map(d => ({
      ...d,
      progress: 0,
      percentage: 0,
    }))
    return NextResponse.json({
      dimensions: defaultDimensions,
      level: calculateLevel(0),
      totalProgress: 0,
      maxProgress: GROWTH_DIMENSIONS.reduce((s, d) => s + d.maxProgress, 0),
    })
  }

  try {
    const supabase = getSupabaseClient(sessionToken)
    const { data: { user }, error: authError } = await supabase.auth.getUser()
    if (authError || !user) {
      return NextResponse.json({ error: "Invalid session" }, { status: 401 })
    }

    const { data: profile } = await supabase
      .from("user_profiles")
      .select("interest, completed_tasks, roundtable_count, letter_count, assessment_result, growth_plan, current_stage")
      .eq("user_id", user.id)
      .single()

    // 计算各维度进度
    const directionProgress = [
      profile?.interest ? 1 : 0,
      profile?.assessment_result ? 1 : 0,
      profile?.growth_plan ? 1 : 0,
    ].reduce((s, v) => s + v, 0)

    const workProgress = Math.min(profile?.completed_tasks || 0, 3)
    const roundtableProgress = Math.min(profile?.roundtable_count || 0, 2)
    const interviewProgress = Math.min(
      Math.floor((profile?.completed_tasks || 0) / 3) + (profile?.assessment_result ? 1 : 0),
      3
    )

    const dimensions = [
      { ...GROWTH_DIMENSIONS[0], progress: directionProgress, percentage: Math.round((directionProgress / GROWTH_DIMENSIONS[0].maxProgress) * 100) },
      { ...GROWTH_DIMENSIONS[1], progress: workProgress, percentage: Math.round((workProgress / GROWTH_DIMENSIONS[1].maxProgress) * 100) },
      { ...GROWTH_DIMENSIONS[2], progress: roundtableProgress, percentage: Math.round((roundtableProgress / GROWTH_DIMENSIONS[2].maxProgress) * 100) },
      { ...GROWTH_DIMENSIONS[3], progress: interviewProgress, percentage: Math.round((interviewProgress / GROWTH_DIMENSIONS[3].maxProgress) * 100) },
    ]

    const totalProgress = dimensions.reduce((s, d) => s + d.progress, 0)
    const maxProgress = GROWTH_DIMENSIONS.reduce((s, d) => s + d.maxProgress, 0)

    return NextResponse.json({
      dimensions,
      level: calculateLevel(totalProgress),
      totalProgress,
      maxProgress,
      stage: profile?.current_stage || "探索期",
    })
  } catch (err) {
    console.error("Growth progress GET error:", err)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
