import { NextRequest, NextResponse } from "next/server"
import { getSupabaseClient } from "@/storage/database/supabase-client"

// GET /api/achievements - 获取所有成就定义 + 当前用户解锁状态
export async function GET(request: NextRequest) {
  const sessionToken = request.headers.get("x-session")

  try {
    const supabase = getSupabaseClient(sessionToken || undefined)

    // 获取所有成就定义
    const { data: definitions, error: defError } = await supabase
      .from("achievement_definitions")
      .select("*")
      .order("sort_order", { ascending: true })

    if (defError) {
      console.error("Achievement definitions fetch error:", defError)
      return NextResponse.json({ error: "Failed to fetch achievements" }, { status: 500 })
    }

    // 如果有 session，获取用户解锁状态
    let unlockedCodes: Set<string> = new Set()
    let profileStats: Record<string, number> = {}

    if (sessionToken) {
      const { data: { user }, error: authError } = await supabase.auth.getUser()
      if (!authError && user) {
        // 获取已解锁成就
        const { data: userAch } = await supabase
          .from("user_achievements")
          .select("achievement_code, unlocked_at")
          .eq("user_id", user.id)

        if (userAch) {
          unlockedCodes = new Set(userAch.map((a: { achievement_code: string }) => a.achievement_code))
        }

        // 获取用户 profile 统计数据
        const { data: profile } = await supabase
          .from("user_profiles")
          .select("interest, completed_tasks, roundtable_count, letter_count, assessment_result, growth_plan")
          .eq("user_id", user.id)
          .single()

        if (profile) {
          profileStats = {
            interest_set: profile.interest ? 1 : 0,
            completed_tasks: profile.completed_tasks || 0,
            roundtable_count: profile.roundtable_count || 0,
            letter_count: profile.letter_count || 0,
            assessment_completed: profile.assessment_result ? 1 : 0,
            growth_plan_generated: profile.growth_plan ? 1 : 0,
            first_visit: 1,
          }
        }
      }
    }

    // 组装成就列表
    const achievements = (definitions || []).map((def: {
      code: string;
      emoji: string;
      name: string;
      description: string;
      category: string;
      condition_type: string;
      condition_value: number;
    }) => ({
      code: def.code,
      emoji: def.emoji,
      name: def.name,
      description: def.description,
      category: def.category,
      conditionType: def.condition_type,
      conditionValue: def.condition_value,
      unlocked: unlockedCodes.has(def.code),
      progress: profileStats[def.condition_type] || 0,
    }))

    return NextResponse.json({ achievements })
  } catch (err) {
    console.error("Achievements GET error:", err)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

// POST /api/achievements - 检查并解锁成就
export async function POST(request: NextRequest) {
  const sessionToken = request.headers.get("x-session")
  if (!sessionToken) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const supabase = getSupabaseClient(sessionToken)
    const { data: { user }, error: authError } = await supabase.auth.getUser()
    if (authError || !user) {
      return NextResponse.json({ error: "Invalid session" }, { status: 401 })
    }

    // 获取用户 profile
    const { data: profile } = await supabase
      .from("user_profiles")
      .select("interest, completed_tasks, roundtable_count, letter_count, assessment_result, growth_plan")
      .eq("user_id", user.id)
      .single()

    const profileStats: Record<string, number> = {
      first_visit: 1,
      interest_set: profile?.interest ? 1 : 0,
      completed_tasks: profile?.completed_tasks || 0,
      roundtable_count: profile?.roundtable_count || 0,
      letter_count: profile?.letter_count || 0,
      assessment_completed: profile?.assessment_result ? 1 : 0,
      growth_plan_generated: profile?.growth_plan ? 1 : 0,
    }

    // 获取所有成就定义
    const { data: definitions } = await supabase
      .from("achievement_definitions")
      .select("code, condition_type, condition_value, emoji, name")

    // 获取已解锁成就
    const { data: existingAch } = await supabase
      .from("user_achievements")
      .select("achievement_code")
      .eq("user_id", user.id)

    const existingCodes = new Set((existingAch || []).map((a: { achievement_code: string }) => a.achievement_code))

    // 检查新解锁的成就
    const newlyUnlocked: { code: string; emoji: string; name: string }[] = []

    for (const def of (definitions || [])) {
      if (existingCodes.has(def.code)) continue
      const currentValue = profileStats[def.condition_type] || 0
      if (currentValue >= def.condition_value) {
        // 解锁成就
        await supabase
          .from("user_achievements")
          .insert({ user_id: user.id, achievement_code: def.code })
        newlyUnlocked.push({ code: def.code, emoji: def.emoji, name: def.name })
      }
    }

    return NextResponse.json({ newlyUnlocked, totalUnlocked: existingCodes.size + newlyUnlocked.length })
  } catch (err) {
    console.error("Achievements POST error:", err)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
