import { NextRequest, NextResponse } from "next/server"
import { LLMClient, type Message } from "coze-coding-dev-sdk"

const client = new LLMClient()

const JOB_RECOMMEND_PROMPT = `你是一位资深互联网行业职业规划师，熟悉腾讯及各大互联网公司的岗位体系和培训计划。

根据用户信息，为其推荐最匹配的3个岗位，并提供针对性的培训学习建议。

## 腾讯主要岗位分类
- **技术类**：软件开发（前端/后端/客户端）、算法工程师、测试开发、安全工程师
- **产品类**：产品策划、产品运营、游戏策划、技术产品
- **设计类**：交互设计、视觉设计、用户研究
- **市场/职能类**：市场策划、品牌管理、HR、财务

## 腾讯BG（事业群）
- WXG：微信事业群
- IEG：互动娱乐事业群（游戏）
- PCG：平台与内容事业群
- CSIG：云与智慧产业事业群
- CDG：企业发展事业群
- TEG：技术工程事业群

请严格按以下JSON格式输出，不要输出其他内容：
{
  "recommendedJobs": [
    {
      "title": "岗位名称",
      "bg": "推荐的事业群",
      "matchScore": 95,
      "reason": "推荐理由（2-3句话）",
      "requiredSkills": ["技能1", "技能2", "技能3"],
      "salaryRange": "薪资范围",
      "developmentPath": "职业发展路径描述"
    }
  ],
  "trainingPlans": [
    {
      "name": "培训计划名称",
      "provider": "提供方（如腾讯课堂/极客时间/Coursera等）",
      "duration": "学习时长",
      "description": "课程描述",
      "link": "搜索关键词",
      "relatedJob": "关联岗位"
    }
  ],
  "suggestions": "整体建议（2-3句话）"
}`

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { grade, interest, assessmentResult, skills } = body

    const userContext = `用户信息：
- 年级：${grade || "未设置"}
- 职业兴趣：${interest || "未设置"}
- 测评结果：${assessmentResult || "未完成测评"}
- 技能/经历：${skills || "暂无"}`

    const allMessages: Message[] = [
      { role: "system" as const, content: JOB_RECOMMEND_PROMPT },
      { role: "user" as const, content: userContext },
    ]

    let fullText = ""
    for await (const chunk of client.stream(allMessages, { model: "doubao-seed-2-0-lite-260215" })) {
      fullText += chunk.content ?? ""
    }

    const jsonMatch = fullText.match(/\{[\s\S]*\}/)
    if (!jsonMatch) {
      return NextResponse.json({ error: "Failed to parse response" }, { status: 500 })
    }

    const result = JSON.parse(jsonMatch[0])
    return NextResponse.json(result)
  } catch (err) {
    const message = err instanceof Error ? err.message : "Unknown error"
    return NextResponse.json({ error: message }, { status: 500 })
  }
}
