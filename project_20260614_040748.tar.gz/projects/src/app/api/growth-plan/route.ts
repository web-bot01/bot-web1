import { NextRequest, NextResponse } from 'next/server';
import { LLMClient, Config } from 'coze-coding-dev-sdk';

export const runtime = 'nodejs';

const GROWTH_PLAN_PROMPT = `你是一位大学生职业成长规划师，擅长根据学生的年级、职业兴趣和当前进度制定个性化的成长计划。

请根据用户的信息，生成一份成长规划。报告必须包含以下JSON结构（不要输出其他内容）：

{
  "summary": "一段60字以内的成长状态总结",
  "currentStage": "探索期/准备期/冲刺期/复盘期",
  "milestones": [
    {
      "id": 1,
      "title": "了解互联网岗位",
      "description": "花一周时间浏览腾讯招聘官网，了解技术/产品/设计/运营四大岗位方向",
      "status": "completed/in_progress/locked",
      "duration": "1周",
      "category": "explore/prepare/sprint/review"
    }
  ],
  "weeklyTasks": [
    {
      "week": "本周",
      "tasks": ["选一个你常用的APP，写下3个你觉得好的设计细节", "阅读一篇产品经理岗位的介绍文章"]
    },
    {
      "week": "下周",
      "tasks": ["用Axure或Figma画一个APP的页面原型", "了解STAR面试法则"]
    },
    {
      "week": "第3周",
      "tasks": ["完成一份产品分析报告", "修改一版简历"]
    }
  ],
  "keyAdvice": "基于你当前阶段最重要的一条建议",
  "resources": [
    {"name": "苏杰《人人都是产品经理》", "type": "book", "reason": "产品入门经典"},
    {"name": "腾讯招聘官网", "type": "website", "reason": "了解真实岗位要求"}
  ]
}

milestones至少5个，weeklyTasks至少3周。根据用户年级和方向调整内容：
- 大一/大二：偏向探索和认知类任务
- 大三/研一：偏向实践和项目类任务
- 大四/研二/研三：偏向求职冲刺类任务`;

export async function POST(request: NextRequest) {
  try {
    const { grade, interest, tasks, roundtables, letters } = await request.json() as {
      grade: string;
      interest: string;
      tasks: number;
      roundtables: number;
      letters: number;
    };

    const config = new Config();
    const client = new LLMClient(config);

    const allMessages = [
      { role: 'system' as const, content: GROWTH_PLAN_PROMPT },
      {
        role: 'user' as const,
        content: `请为我制定成长规划。我的信息：年级=${grade}，职业兴趣=${interest}，已完成任务=${tasks}个，参加圆桌=${roundtables}次，收到回信=${letters}封`,
      },
    ];

    // Collect stream into full text
    let text = '';
    for await (const chunk of client.stream(allMessages, { model: 'doubao-seed-2-0-pro-260215' })) {
      text += chunk.content ?? '';
    }
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      const parsed = JSON.parse(jsonMatch[0]);
      return NextResponse.json(parsed);
    }
    return NextResponse.json({ error: 'Failed to parse growth plan', raw: text }, { status: 500 });
  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : 'Unknown error';
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}
