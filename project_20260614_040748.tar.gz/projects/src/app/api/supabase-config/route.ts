import { NextResponse } from 'next/server';
import { getSupabaseCredentials } from '@/storage/database/supabase-client';

export async function GET() {
  try {
    const { url, anonKey } = getSupabaseCredentials();

    if (!url || !anonKey) {
      return NextResponse.json({
        configured: false,
        message: 'Supabase is not configured. Login and profile features are unavailable.',
      });
    }

    return NextResponse.json({
      configured: true,
      url,
      anonKey,
    });
  } catch {
    return NextResponse.json({
      configured: false,
      message: 'Supabase is not configured. Login and profile features are unavailable.',
    });
  }
}
