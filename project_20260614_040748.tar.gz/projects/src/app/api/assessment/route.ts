import { NextRequest, NextResponse } from 'next/server';
import { LLMClient, Config } from 'coze-coding-dev-sdk';

export const runtime = 'nodejs';

const ASSESSMENT_PROMPT = `你是一位专业的职业规划师，擅长通过霍兰德职业兴趣理论帮助大学生找到适合自己的职业方向。

请根据用户的回答，生成一份职业测评报告。报告必须包含以下JSON结构（不要输出其他内容）：

{
  "hollandCode": "三个字母的霍兰德代码，如IRA",
  "hollandDescription": "对这三个字母组合的简要解释",
  "dimensions": [
    {"name": "I研究型", "score": 85, "description": "喜欢观察、学习、研究、分析、评估和解决问题"},
    {"name": "R实用型", "score": 60, "description": "喜欢使用工具、机械、动手操作"},
    {"name": "A艺术型", "score": 70, "description": "喜欢创造性、非结构化的活动"},
    {"name": "S社会型", "score": 75, "description": "喜欢与人合作、帮助、培训或治疗他人"},
    {"name": "E企业型", "score": 55, "description": "喜欢影响、领导他人，追求组织目标和经济利益"},
    {"name": "C常规型", "score": 45, "description": "喜欢明确的规则、有序的数据处理"}
  ],
  "recommendedRoles": [
    {"name": "产品经理", "match": 92, "reason": "你的分析能力和用户洞察力非常适合产品岗位"},
    {"name": "数据分析师", "match": 85, "reason": "你的研究型特质与数据驱动决策高度匹配"},
    {"name": "用户研究员", "match": 80, "reason": "你的社会型+研究型组合非常适合理解用户需求"}
  ],
  "strengths": ["分析能力强", "善于发现问题", "逻辑清晰"],
  "suggestions": "建议先从产品分析报告入手，积累对用户需求的理解..."
}

请根据用户的回答内容，生成合理的测评结果。`;

export async function POST(request: NextRequest) {
  try {
    const { answers, grade } = await request.json() as { answers: string; grade: string };

    const config = new Config();
    const client = new LLMClient(config);

    const allMessages = [
      { role: 'system' as const, content: ASSESSMENT_PROMPT },
      { role: 'user' as const, content: `我的年级是${grade}，以下是我的回答：\n${answers}` },
    ];

    // Collect stream into full text
    let text = '';
    for await (const chunk of client.stream(allMessages, { model: 'doubao-seed-2-0-pro-260215' })) {
      text += chunk.content ?? '';
    }
    // Try to extract JSON from the response
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      const parsed = JSON.parse(jsonMatch[0]);
      return NextResponse.json(parsed);
    }
    return NextResponse.json({ error: 'Failed to parse assessment result', raw: text }, { status: 500 });
  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : 'Unknown error';
    return NextResponse.json({ error: msg }, { status: 500 });
  }
}
