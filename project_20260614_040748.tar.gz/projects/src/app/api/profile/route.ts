import { NextRequest, NextResponse } from "next/server"
import { getSupabaseClient } from "@/storage/database/supabase-client"

export async function GET(request: NextRequest) {
  const sessionToken = request.headers.get("x-session")
  if (!sessionToken) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const supabase = getSupabaseClient(sessionToken)
    const { data: { user }, error: authError } = await supabase.auth.getUser()
    if (authError || !user) {
      return NextResponse.json({ error: "Invalid session" }, { status: 401 })
    }

    const { data: profile, error: profileError } = await supabase
      .from("user_profiles")
      .select("*")
      .eq("user_id", user.id)
      .single()

    if (profileError && profileError.code !== "PGRST116") {
      console.error("Profile fetch error:", profileError)
    }

    return NextResponse.json({
      user: {
        id: user.id,
        email: user.email,
      },
      profile: profile || null,
    })
  } catch (err) {
    console.error("Profile GET error:", err)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  const sessionToken = request.headers.get("x-session")
  if (!sessionToken) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const body = await request.json()
    const supabase = getSupabaseClient(sessionToken)
    const { data: { user }, error: authError } = await supabase.auth.getUser()
    if (authError || !user) {
      return NextResponse.json({ error: "Invalid session" }, { status: 401 })
    }

    const updateData: Record<string, unknown> = {}
    const allowedFields = ["nickname", "grade", "interest", "avatar_url", "achievements", "super_powers", "current_stage", "completed_tasks", "roundtable_count", "letter_count", "assessment_result", "growth_plan"]

    for (const field of allowedFields) {
      if (body[field] !== undefined) {
        updateData[field] = body[field]
      }
    }

    updateData["updated_at"] = new Date().toISOString()

    const { data: existingProfile } = await supabase
      .from("user_profiles")
      .select("user_id")
      .eq("user_id", user.id)
      .single()

    let result
    if (existingProfile) {
      result = await supabase
        .from("user_profiles")
        .update(updateData)
        .eq("user_id", user.id)
        .select()
        .single()
    } else {
      updateData["user_id"] = user.id
      result = await supabase
        .from("user_profiles")
        .insert(updateData)
        .select()
        .single()
    }

    if (result.error) {
      console.error("Profile upsert error:", result.error)
      return NextResponse.json({ error: result.error.message }, { status: 500 })
    }

    return NextResponse.json({ profile: result.data })
  } catch (err) {
    console.error("Profile POST error:", err)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

export async function PUT(request: NextRequest) {
  const sessionToken = request.headers.get("x-session")
  if (!sessionToken) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  try {
    const body = await request.json()
    const supabase = getSupabaseClient(sessionToken)
    const { data: { user }, error: authError } = await supabase.auth.getUser()
    if (authError || !user) {
      return NextResponse.json({ error: "Invalid session" }, { status: 401 })
    }

    const updateData: Record<string, unknown> = {}
    const allowedFields = ["nickname", "grade", "interest", "avatar_url", "super_powers", "current_stage", "assessment_result", "growth_plan"]

    for (const field of allowedFields) {
      if (body[field] !== undefined) {
        updateData[field] = body[field]
      }
    }

    updateData["updated_at"] = new Date().toISOString()

    const { data: existingProfile } = await supabase
      .from("user_profiles")
      .select("user_id")
      .eq("user_id", user.id)
      .single()

    let result
    if (existingProfile) {
      result = await supabase
        .from("user_profiles")
        .update(updateData)
        .eq("user_id", user.id)
        .select()
        .single()
    } else {
      updateData["user_id"] = user.id
      result = await supabase
        .from("user_profiles")
        .insert(updateData)
        .select()
        .single()
    }

    if (result.error) {
      console.error("Profile PUT error:", result.error)
      return NextResponse.json({ error: result.error.message }, { status: 500 })
    }

    return NextResponse.json({ profile: result.data })
  } catch (err) {
    console.error("Profile PUT error:", err)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
