'use client';

import { useState, useCallback } from 'react';
import { useRouter } from 'next/navigation';

interface JobRecommend {
  job_title: string;
  department: string;
  match_score: number;
  description: string;
  requirements: string[];
  courses: { title: string; url: string }[];
  skills_gap: string[];
  growth_path: string;
}

export default function JobsPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [jobs, setJobs] = useState<JobRecommend[]>([]);
  const [userGrade, setUserGrade] = useState('');
  const [userInterest, setUserInterest] = useState('');
  const [selectedDept, setSelectedDept] = useState('all');

  const departments = [
    { id: 'all', name: '全部', icon: '🏢' },
    { id: 'WXG', name: 'WXG 微信', icon: '💬' },
    { id: 'IEG', name: 'IEG 互动娱乐', icon: '🎮' },
    { id: 'PCG', name: 'PCG 平台与内容', icon: '📺' },
    { id: 'CSIG', name: 'CSIG 云与智慧', icon: '☁️' },
    { id: 'CDG', name: 'CDG 企业发展', icon: '💼' },
    { id: 'TEG', name: 'TEG 技术工程', icon: '⚙️' },
  ];

  const fetchJobs = async (grade: string, interest: string) => {
    setLoading(true);
    try {
      const res = await fetch('/api/job-recommend', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ grade, interest }),
      });
      if (res.ok) {
        const data = await res.json();
        setJobs(data.recommendations || []);
      }
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = () => {
    if (userGrade && userInterest) {
      fetchJobs(userGrade, userInterest);
    }
  };

  const filteredJobs = selectedDept === 'all'
    ? jobs
    : jobs.filter((j) => j.department?.includes(selectedDept));

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-white to-teal-50">
      {/* Top Nav */}
      <nav className="bg-gradient-to-r from-emerald-500 to-emerald-600 text-white px-4 py-3 flex items-center gap-3 sticky top-0 z-10">
        <button onClick={() => router.push('/')} className="p-1 hover:bg-white/20 rounded-lg transition-colors">
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" /></svg>
        </button>
        <h1 className="font-bold">岗位智能推荐</h1>
      </nav>

      <div className="max-w-3xl mx-auto p-4 space-y-4">
        {/* Search Card */}
        <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100">
          <h3 className="font-bold text-gray-800 mb-3">🎯 智能匹配岗位</h3>
          <div className="flex gap-3 mb-3">
            <select
              value={userGrade}
              onChange={(e) => setUserGrade(e.target.value)}
              className="flex-1 px-3 py-2.5 rounded-xl border border-gray-200 text-sm focus:border-emerald-500 outline-none"
            >
              <option value="">选择年级</option>
              {['大一', '大二', '大三', '大四', '研一', '研二', '研三', '已毕业'].map((g) => (
                <option key={g} value={g}>{g}</option>
              ))}
            </select>
            <input
              type="text"
              value={userInterest}
              onChange={(e) => setUserInterest(e.target.value)}
              placeholder="职业兴趣（如产品经理）"
              className="flex-1 px-3 py-2.5 rounded-xl border border-gray-200 text-sm focus:border-emerald-500 outline-none"
            />
            <button
              onClick={handleSearch}
              disabled={loading || !userGrade || !userInterest}
              className="px-5 py-2.5 rounded-xl bg-emerald-500 text-white text-sm font-medium hover:bg-emerald-600 transition-colors disabled:opacity-50"
            >
              {loading ? '匹配中...' : '匹配'}
            </button>
          </div>
        </div>

        {/* Department Filter */}
        <div className="flex gap-2 overflow-x-auto pb-2">
          {departments.map((dept) => (
            <button
              key={dept.id}
              onClick={() => setSelectedDept(dept.id)}
              className={`flex-shrink-0 px-3 py-2 rounded-xl text-sm font-medium transition-all flex items-center gap-1.5 ${
                selectedDept === dept.id
                  ? 'bg-emerald-500 text-white shadow-md'
                  : 'bg-white text-gray-600 border border-gray-200 hover:border-emerald-300'
              }`}
            >
              <span>{dept.icon}</span>
              <span>{dept.name}</span>
            </button>
          ))}
        </div>

        {/* Job Cards */}
        {loading && (
          <div className="text-center py-10">
            <div className="text-4xl animate-bounce-slow mb-3">🐧</div>
            <p className="text-emerald-600">正在为你匹配最佳岗位...</p>
          </div>
        )}

        {!loading && filteredJobs.length === 0 && (
          <div className="text-center py-10 bg-white rounded-2xl border border-gray-100">
            <div className="text-4xl mb-3">🔍</div>
            <p className="text-gray-500">选择年级和兴趣，发现适合你的岗位</p>
          </div>
        )}

        {!loading && filteredJobs.map((job, idx) => (
          <div key={idx} className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
            <div className="flex items-start justify-between mb-3">
              <div>
                <h4 className="font-bold text-gray-800 text-lg">{job.job_title}</h4>
                <p className="text-sm text-emerald-600">{job.department}</p>
              </div>
              <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50">
                <span className="text-emerald-600 font-bold text-lg">{job.match_score}</span>
                <span className="text-emerald-500 text-xs">匹配</span>
              </div>
            </div>

            <p className="text-sm text-gray-600 mb-3">{job.description}</p>

            {/* Skills Gap */}
            {job.skills_gap && job.skills_gap.length > 0 && (
              <div className="mb-3">
                <p className="text-xs text-gray-500 mb-1.5">待提升技能</p>
                <div className="flex flex-wrap gap-1.5">
                  {job.skills_gap.map((skill: string) => (
                    <span key={skill} className="px-2.5 py-1 rounded-full bg-orange-50 text-orange-600 text-xs font-medium">{skill}</span>
                  ))}
                </div>
              </div>
            )}

            {/* Requirements */}
            {job.requirements && job.requirements.length > 0 && (
              <div className="mb-3">
                <p className="text-xs text-gray-500 mb-1.5">岗位要求</p>
                <ul className="space-y-1">
                  {job.requirements.slice(0, 3).map((req: string, i: number) => (
                    <li key={i} className="text-sm text-gray-600 flex items-start gap-1.5">
                      <span className="text-emerald-500 mt-0.5">•</span>
                      {req}
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {/* Courses */}
            {job.courses && job.courses.length > 0 && (
              <div className="mb-3">
                <p className="text-xs text-gray-500 mb-1.5">📚 推荐课程</p>
                <div className="space-y-1.5">
                  {job.courses.slice(0, 3).map((course: { title: string; url: string }, i: number) => (
                    <a
                      key={i}
                      href={course.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="block text-sm text-blue-600 hover:text-blue-700 hover:underline truncate"
                    >
                      📖 {course.title}
                    </a>
                  ))}
                </div>
              </div>
            )}

            {/* Growth Path */}
            {job.growth_path && (
              <div className="mt-3 p-3 rounded-xl bg-emerald-50">
                <p className="text-xs text-emerald-600 font-medium mb-1">🚀 成长路径</p>
                <p className="text-sm text-emerald-700">{job.growth_path}</p>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
}
