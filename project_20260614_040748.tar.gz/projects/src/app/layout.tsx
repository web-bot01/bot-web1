import type { Metadata } from 'next';
import { Inspector } from 'react-dev-inspector';
import { SupabaseConfigProvider } from '@/lib/supabase-config-inject';
import './globals.css';

export const metadata: Metadata = {
  title: {
    default: '鹅小伴 | AI 职业成长陪伴',
    template: '%s | 鹅小伴',
  },
  description: '鹅小伴 — 鹅厂PM学长，陪伴大学生探索职业方向、缓解求职焦虑',
  keywords: ['鹅小伴', 'AI', '职业成长', '求职', '大学生'],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const isDev = process.env.COZE_PROJECT_ENV === 'DEV';

  return (
    <html lang="en">
      <body className={`antialiased`}>
        <SupabaseConfigProvider>
          {isDev && <Inspector />}
          {children}
        </SupabaseConfigProvider>
      </body>
    </html>
  );
}
