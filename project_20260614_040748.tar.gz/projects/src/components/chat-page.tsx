'use client';

import { useState, useRef, useEffect, useCallback, FormEvent } from 'react';
import { useRouter } from 'next/navigation';

/* ------------------------------------------------------------------ */
/*  Types                                                              */
/* ------------------------------------------------------------------ */
interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
}

interface UserProfile {
  nickname: string;
  grade: string;
  interest: string;
  tasks: number;
  roundtables: number;
  letters: number;
  achievements: string[];
  superpowers: string[];
  level: number;
  levelName: string;
}

interface GrowthDimension {
  key: string;
  label: string;
  maxProgress: number;
  description: string;
  progress: number;
  percentage: number;
}

interface GrowthProgress {
  dimensions: GrowthDimension[];
  level: { level: number; name: string; exp: number; expToNext: number; expInLevel: number };
  totalProgress: number;
  maxProgress: number;
  stage: string;
}

interface AssessmentResult {
  hollandCode: string;
  hollandDescription: string;
  dimensions: { name: string; score: number; description: string }[];
  recommendedRoles: { name: string; match: number; reason: string }[];
  strengths: string[];
  suggestions: string;
}

interface GrowthPlan {
  summary: string;
  currentStage: string;
  milestones: { id: number; title: string; description: string; status: string; duration: string; category: string }[];
  weeklyTasks: { week: string; tasks: string[] }[];
  keyAdvice: string;
  resources: { name: string; type: string; reason: string }[];
}

type ModuleTab = 'grade' | 'assessment' | 'chat' | 'plan';

/* ------------------------------------------------------------------ */
/*  Constants                                                          */
/* ------------------------------------------------------------------ */
const GRADES = [
  { value: '大一', label: '大一', desc: '好奇探索期', icon: '🌱', color: 'emerald' },
  { value: '大二', label: '大二', desc: '能力构建期', icon: '🌿', color: 'green' },
  { value: '大三', label: '大三', desc: '实习冲刺期', icon: '🚀', color: 'teal' },
  { value: '大四', label: '大四', desc: '求职决战期', icon: '⚔️', color: 'orange' },
  { value: '研一', label: '研一', desc: '深入规划期', icon: '🔬', color: 'blue' },
  { value: '研二', label: '研二', desc: '求职冲刺期', icon: '🎯', color: 'indigo' },
  { value: '研三', label: '研三', desc: '毕业冲刺期', icon: '🎓', color: 'purple' },
  { value: '已毕业', label: '已毕业', desc: '职场新人期', icon: '💼', color: 'slate' },
];

const ASSESSMENT_QUESTIONS = [
  {
    id: 1,
    question: '你更喜欢哪种工作方式？',
    options: [
      { label: '独自钻研技术难题', value: 'I' },
      { label: '动手做出实际产品', value: 'R' },
      { label: '发挥创意设计作品', value: 'A' },
      { label: '帮助他人解决问题', value: 'S' },
    ],
  },
  {
    id: 2,
    question: '你在团队中最常扮演什么角色？',
    options: [
      { label: '分析问题、提供数据支撑', value: 'I' },
      { label: '执行落地、推动进展', value: 'E' },
      { label: '协调关系、凝聚团队', value: 'S' },
      { label: '整理信息、保持秩序', value: 'C' },
    ],
  },
  {
    id: 3,
    question: '哪种场景最能让你进入"心流"状态？',
    options: [
      { label: '研究一个复杂问题的来龙去脉', value: 'I' },
      { label: '把一个想法变成可见的产品', value: 'R' },
      { label: '用设计表达一个理念', value: 'A' },
      { label: '和一群人讨论出共识', value: 'S' },
    ],
  },
  {
    id: 4,
    question: '你对"互联网行业"最感兴趣的是？',
    options: [
      { label: '算法和推荐系统背后的逻辑', value: 'I' },
      { label: 'APP的功能设计和用户体验', value: 'A' },
      { label: '商业模式的运作和增长', value: 'E' },
      { label: '帮助用户解决问题的过程', value: 'S' },
    ],
  },
  {
    id: 5,
    question: '如果让你选一个周末活动，你会选？',
    options: [
      { label: '阅读一本行业深度分析的书', value: 'I' },
      { label: '参加黑客松，做一个原型', value: 'R' },
      { label: '逛展、拍照、记录灵感', value: 'A' },
      { label: '和朋友聊天，听他们的故事', value: 'S' },
    ],
  },
  {
    id: 6,
    question: '你觉得自己的最大优势是？',
    options: [
      { label: '逻辑分析和深度思考', value: 'I' },
      { label: '动手能力和执行力', value: 'R' },
      { label: '创意和审美', value: 'A' },
      { label: '沟通和共情能力', value: 'S' },
    ],
  },
  {
    id: 7,
    question: '面对一个新项目，你第一反应是？',
    options: [
      { label: '先调研，搞清楚背景和数据', value: 'I' },
      { label: '直接动手试，边做边学', value: 'R' },
      { label: '先构思一个有创意的方案', value: 'A' },
      { label: '先找人聊，了解需求', value: 'S' },
    ],
  },
  {
    id: 8,
    question: '哪种工作成果最让你有成就感？',
    options: [
      { label: '发现了一个别人没注意到的规律', value: 'I' },
      { label: '做出了一个能用的产品功能', value: 'R' },
      { label: '设计出了一个漂亮的方案', value: 'A' },
      { label: '帮助团队达成了一个目标', value: 'E' },
    ],
  },
];

const QUICK_QUESTIONS = [
  '我是二本学生，怎么突破学历限制？',
  '大学里要不要卷实习？',
  '专业和职业不对口怎么办？',
  '0经验怎么写简历？',
  '给我讲一个前辈的真实故事',
  '给我布置一个本周可以完成的小任务',
];

const DEFAULT_PROFILE: UserProfile = {
  nickname: '',
  grade: '',
  interest: '',
  tasks: 0,
  roundtables: 0,
  letters: 0,
  achievements: ['🌱 初来乍到'],
  superpowers: [],
  level: 1,
  levelName: '探索新手',
};

/* ------------------------------------------------------------------ */
/*  Module Tabs                                                        */
/* ------------------------------------------------------------------ */
const MODULE_TABS: { key: ModuleTab; label: string; icon: string }[] = [
  { key: 'grade', label: '年级选择', icon: '🎓' },
  { key: 'assessment', label: '职业测评', icon: '🧭' },
  { key: 'chat', label: 'AI 对话', icon: '💬' },
  { key: 'plan', label: '成长规划', icon: '🗺️' },
];

/* ================================================================== */
/*  Onboarding Overlay Component                                       */
/* ================================================================== */

const ONBOARDING_STEPS = [
  {
    icon: "🎓",
    title: "年级选择",
    desc: "告诉我你现在读大几，我会根据你的阶段给出最合适的建议",
    color: "from-emerald-400 to-emerald-500",
  },
  {
    icon: "🧭",
    title: "职业测评",
    desc: "5道趣味测评题，帮你发现最适合的职业方向",
    color: "from-teal-400 to-teal-500",
  },
  {
    icon: "💬",
    title: "AI 陪伴对话",
    desc: "鹅小伴学长陪你聊困惑、解焦虑、听故事、领任务",
    color: "from-cyan-400 to-cyan-500",
  },
  {
    icon: "🗺️",
    title: "成长规划",
    desc: "个性化成长路径、每周任务、资源推荐，一步步走向目标",
    color: "from-sky-400 to-sky-500",
  },
];

function OnboardingOverlay({ onComplete }: { onComplete: () => void }) {
  const [step, setStep] = useState(0);
  const [leaving, setLeaving] = useState(false);

  const handleNext = () => {
    if (step < ONBOARDING_STEPS.length - 1) {
      setStep(step + 1);
    } else {
      setLeaving(true);
      setTimeout(() => {
        onComplete();
      }, 500);
    }
  };

  const handleSkip = () => {
    setLeaving(true);
    setTimeout(() => {
      onComplete();
    }, 500);
  };

  const current = ONBOARDING_STEPS[step];

  return (
    <div
      className={`fixed inset-0 z-50 flex items-center justify-center bg-slate-900/80 backdrop-blur-sm transition-opacity duration-500 ${
        leaving ? "opacity-0" : "opacity-100"
      }`}
    >
      <div
        className={`relative w-full max-w-md mx-4 bg-white rounded-3xl shadow-2xl overflow-hidden transition-all duration-500 ${
          leaving ? "scale-95 translate-y-8" : "scale-100 translate-y-0"
        }`}
      >
        {/* Top gradient banner */}
        <div
          className={`relative h-48 bg-gradient-to-br ${current.color} flex items-center justify-center transition-all duration-500`}
        >
          <span className="text-7xl animate-bounce-slow">{current.icon}</span>
          {/* Decorative circles */}
          <div className="absolute top-4 right-4 w-16 h-16 rounded-full bg-white/10" />
          <div className="absolute bottom-6 left-6 w-10 h-10 rounded-full bg-white/10" />
          <div className="absolute top-12 left-10 w-6 h-6 rounded-full bg-white/15" />
        </div>

        {/* Content */}
        <div className="px-8 pt-6 pb-4">
          <h2 className="text-2xl font-bold text-slate-800 mb-2">
            {current.title}
          </h2>
          <p className="text-slate-500 text-base leading-relaxed">
            {current.desc}
          </p>
        </div>

        {/* Step indicators */}
        <div className="flex items-center justify-center gap-2 px-8 pb-4">
          {ONBOARDING_STEPS.map((_, i) => (
            <div
              key={i}
              className={`h-1.5 rounded-full transition-all duration-300 ${
                i === step
                  ? "w-8 bg-emerald-500"
                  : i < step
                  ? "w-4 bg-emerald-300"
                  : "w-4 bg-slate-200"
              }`}
            />
          ))}
        </div>

        {/* Actions */}
        <div className="flex items-center justify-between px-8 pb-8 pt-2">
          <button
            onClick={handleSkip}
            className="text-sm text-slate-400 hover:text-slate-600 transition-colors"
          >
            跳过
          </button>
          <button
            onClick={handleNext}
            className="px-8 py-3 bg-gradient-to-r from-emerald-500 to-emerald-600 text-white rounded-full font-medium shadow-lg shadow-emerald-500/25 hover:shadow-emerald-500/40 hover:scale-105 active:scale-95 transition-all duration-200"
          >
            {step < ONBOARDING_STEPS.length - 1 ? "下一步" : "开始体验"}
          </button>
        </div>

        {/* Penguin watermark */}
        <div className="absolute bottom-2 right-4 text-3xl opacity-10">🐧</div>
      </div>
    </div>
  );
}

/* ================================================================== */
/*  Main Component                                                     */
/* ================================================================== */
export default function ChatPage() {
  const router = useRouter();
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [onboardingStep, setOnboardingStep] = useState(0);
  const [activeTab, setActiveTab] = useState<ModuleTab>('grade');
  const [profile, setProfile] = useState<UserProfile>(DEFAULT_PROFILE);
  const [nicknameInput, setNicknameInput] = useState('');
  const [sidebarOpen, setSidebarOpen] = useState(false);

  // Assessment state
  const [assessStep, setAssessStep] = useState(0);
  const [assessAnswers, setAssessAnswers] = useState<Record<number, string>>({});
  const [assessResult, setAssessResult] = useState<AssessmentResult | null>(null);
  const [assessLoading, setAssessLoading] = useState(false);

  // Chat state
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isStreaming, setIsStreaming] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  // Growth plan state
  const [growthPlan, setGrowthPlan] = useState<GrowthPlan | null>(null);
  const [planLoading, setPlanLoading] = useState(false);

  // Growth progress state (from API)
  const [growthProgress, setGrowthProgress] = useState<GrowthProgress | null>(null);

  /* ---- Growth Progress Fetch ---- */
  const fetchGrowthProgress = useCallback(async () => {
    try {
      const headers: Record<string, string> = {};
      // Try to get session token if logged in
      try {
        const { getSupabaseBrowserClientWithRetry } = await import('@/lib/supabase-browser');
        const supabase = await getSupabaseBrowserClientWithRetry();
        const { data: { session } } = await supabase.auth.getSession();
        if (session?.access_token) {
          headers['x-session'] = session.access_token;
        }
      } catch { /* not configured, use default */ }

      const res = await fetch('/api/growth-progress', { headers });
      if (res.ok) {
        const data = await res.json();
        setGrowthProgress(data);
        // Update profile level from growth progress
        if (data.level) {
          setProfile(prev => ({
            ...prev,
            level: data.level.level,
            levelName: data.level.name,
            interest: data.dimensions?.[0]?.progress > 0 ? (prev.interest || '探索中') : prev.interest,
          }));
        }
      }
    } catch { /* fetch failed, use defaults */ }
  }, []);

  /* ---- Effects ---- */
  useEffect(() => {
    const visited = localStorage.getItem('ex-goose-onboarded');
    if (!visited) {
      setShowOnboarding(true);
    }
    fetchGrowthProgress();
  }, [fetchGrowthProgress]);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
      textareaRef.current.style.height = Math.min(textareaRef.current.scrollHeight, 120) + 'px';
    }
  }, [input]);

  /* ---- Grade Selection ---- */
  const handleOnboardingComplete = () => {
    localStorage.setItem('ex-goose-onboarded', '1');
    setShowOnboarding(false);
    fetchGrowthProgress(); // refresh on first visit
  };

  const handleGradeSelect = (grade: string) => {
    setProfile(prev => ({ ...prev, grade }));
    if (profile.nickname && !profile.interest) {
      setActiveTab('assessment');
    } else if (profile.nickname) {
      setActiveTab('chat');
    }
  };

  const handleNicknameSubmit = () => {
    if (nicknameInput.trim()) {
      setProfile(prev => ({ ...prev, nickname: nicknameInput.trim() }));
      setNicknameInput('');
    }
  };

  /* ---- Assessment ---- */
  const handleAssessAnswer = (questionId: number, value: string) => {
    setAssessAnswers(prev => ({ ...prev, [questionId]: value }));
    if (assessStep < ASSESSMENT_QUESTIONS.length - 1) {
      setAssessStep(prev => prev + 1);
    }
  };

  const handleAssessSubmit = async () => {
    setAssessLoading(true);
    try {
      const answerText = ASSESSMENT_QUESTIONS.map(q => {
        const ans = assessAnswers[q.id];
        const opt = q.options.find(o => o.value === ans);
        return `Q${q.id}: ${q.question} → ${opt?.label ?? ans}`;
      }).join('\n');

      const res = await fetch('/api/assessment', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ answers: answerText, grade: profile.grade }),
      });
      const data = await res.json();
      if (data.hollandCode) {
        setAssessResult(data);
        // Extract interest from top recommendation
        if (data.recommendedRoles?.[0]?.name) {
          setProfile(prev => ({ ...prev, interest: data.recommendedRoles[0].name }));
        }
      }
    } catch {
      // Silently handle
    } finally {
      setAssessLoading(false);
    }
  };

  const resetAssessment = () => {
    setAssessStep(0);
    setAssessAnswers({});
    setAssessResult(null);
  };

  /* ---- Chat ---- */
  const sendMessage = useCallback(async (content: string) => {
    if (!content.trim() || isStreaming) return;
    const userMsg: Message = { id: `u-${Date.now()}`, role: 'user', content: content.trim() };
    const assistantMsg: Message = { id: `a-${Date.now()}`, role: 'assistant', content: '' };
    setMessages(prev => [...prev, userMsg, assistantMsg]);
    setInput('');
    setIsStreaming(true);

    try {
      const history = messages
        .filter(m => m.content)
        .map(m => ({ role: m.role as 'user' | 'assistant', content: m.content }));

      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messages: [...history, { role: 'user' as const, content: content.trim() }] }),
      });

      if (!res.ok || !res.body) throw new Error('Request failed');

      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });

        const lines = buffer.split('\n');
        buffer = lines.pop() ?? '';

        for (const line of lines) {
          const trimmed = line.trim();
          if (trimmed === 'data: [DONE]') break;
          if (trimmed.startsWith('data: ')) {
            try {
              const parsed = JSON.parse(trimmed.slice(6));
              if (parsed.content) {
                assistantMsg.content += parsed.content;
                setMessages(prev =>
                  prev.map(m => (m.id === assistantMsg.id ? { ...m, content: assistantMsg.content } : m)),
                );
              }
            } catch {
              // skip
            }
          }
        }
      }
    } catch {
      assistantMsg.content = '网络似乎出了点问题，稍后再试试吧 😅';
      setMessages(prev => prev.map(m => (m.id === assistantMsg.id ? { ...m, content: assistantMsg.content } : m)));
    } finally {
      setIsStreaming(false);
    }
  }, [isStreaming, messages]);

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    sendMessage(input);
  };

  /* ---- Growth Plan ---- */
  const generateGrowthPlan = async () => {
    setPlanLoading(true);
    try {
      const res = await fetch('/api/growth-plan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          grade: profile.grade,
          interest: profile.interest || '暂未确定',
          tasks: profile.tasks,
          roundtables: profile.roundtables,
          letters: profile.letters,
        }),
      });
      const data = await res.json();
      if (data.milestones) {
        setGrowthPlan(data);
      }
    } catch {
      // Silently handle
    } finally {
      setPlanLoading(false);
    }
  };

  /* ---- Quick action (sidebar & welcome) ---- */
  const handleQuickAction = (prompt: string) => {
    setActiveTab('chat');
    setTimeout(() => sendMessage(prompt), 100);
  };

  /* ---- Markdown-lite renderer ---- */
  const renderContent = (text: string) => {
    const lines = text.split('\n');
    return lines.map((line, i) => {
      // Horizontal rule
      if (/^─{3,}$/.test(line.trim()) || /^━━{3,}$/.test(line.trim())) {
        return <hr key={i} className="my-2 border-emerald-200" />;
      }
      // Heading
      if (line.startsWith('### ')) return <h3 key={i} className="text-base font-bold mt-3 mb-1">{line.slice(4)}</h3>;
      if (line.startsWith('## ')) return <h2 key={i} className="text-lg font-bold mt-3 mb-1">{line.slice(3)}</h2>;
      if (line.startsWith('# ')) return <h1 key={i} className="text-xl font-bold mt-3 mb-1">{line.slice(2)}</h1>;
      // Blockquote
      if (line.startsWith('> ')) return <blockquote key={i} className="border-l-3 border-emerald-400 pl-3 text-gray-600 italic my-1">{renderInline(line.slice(2))}</blockquote>;
      // List
      if (/^[\d]+[.)]\s/.test(line)) return <div key={i} className="ml-4 my-0.5">{renderInline(line)}</div>;
      if (/^[•\-]\s/.test(line.trim())) return <div key={i} className="ml-4 my-0.5">• {renderInline(line.trim().slice(2))}</div>;
      // Empty
      if (!line.trim()) return <div key={i} className="h-2" />;
      // Normal
      return <div key={i} className="my-0.5">{renderInline(line)}</div>;
    });
  };

  const renderInline = (text: string) => {
    const parts = text.split(/(\*\*[^*]+\*\*|`[^`]+`)/g);
    return parts.map((part, i) => {
      if (part.startsWith('**') && part.endsWith('**'))
        return <strong key={i}>{part.slice(2, -2)}</strong>;
      if (part.startsWith('`') && part.endsWith('`'))
        return <code key={i} className="bg-emerald-50 px-1 rounded text-sm">{part.slice(1, -1)}</code>;
      return part;
    });
  };

  /* ================================================================ */
  /*  RENDER                                                           */
  /* ================================================================ */
  return (
    <div className="flex h-screen bg-slate-50 overflow-hidden">
      {/* ---- Onboarding Overlay ---- */}
      {showOnboarding && (
        <OnboardingOverlay onComplete={handleOnboardingComplete} />
      )}

      {/* ---- Mobile menu button ---- */}
      <button
        onClick={() => setSidebarOpen(!sidebarOpen)}
        className="fixed top-3 left-3 z-50 md:hidden bg-emerald-500 text-white p-2 rounded-lg shadow-lg"
        aria-label="菜单"
      >
        <svg width="20" height="20" fill="none" stroke="currentColor" strokeWidth="2"><path d="M3 6h14M3 10h14M3 14h14" /></svg>
      </button>

      {/* ---- Left Sidebar ---- */}
      <aside className={`
        fixed md:static z-40 h-full w-80 flex-shrink-0 bg-white border-r border-slate-100
        transition-transform duration-300 ease-out overflow-y-auto
        ${sidebarOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'}
      `}>
        <div className="p-5 space-y-4">
          {/* Brand */}
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-emerald-500 rounded-xl flex items-center justify-center text-xl">🐧</div>
              <div>
                <h1 className="font-bold text-lg text-slate-800">未来鹅</h1>
                <p className="text-xs text-slate-400">你的职业成长AI陪伴</p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => router.push('/profile')}
              className="w-9 h-9 bg-emerald-50 hover:bg-emerald-100 rounded-full flex items-center justify-center text-emerald-600 transition-colors"
              title="个人中心"
            >
              👤
            </button>
          </div>

          {/* Profile Card - Clickable to Profile Page */}
          <button
            type="button"
            onClick={() => router.push('/profile')}
            className="w-full text-left bg-gradient-to-br from-emerald-600 to-emerald-700 rounded-2xl p-4 text-white hover:shadow-lg hover:shadow-emerald-200 transition-all cursor-pointer group"
          >
            <p className="text-xs opacity-70 mb-1">未来鹅 · 成长宇宙</p>
            <h2 className="text-lg font-bold group-hover:translate-x-1 transition-transform">{profile.nickname || '你的星球'}</h2>
            <p className="text-xs opacity-80 mb-3">{profile.nickname ? '正在发光中 ✨' : '设置昵称开始探索'}</p>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="bg-white/10 rounded-lg p-2">
                <span className="opacity-70">年级</span>
                <p className="font-semibold">{profile.grade || '未选择'}</p>
              </div>
              <div className="bg-white/10 rounded-lg p-2">
                <span className="opacity-70">方向</span>
                <p className="font-semibold">{profile.interest || '待探索'}</p>
              </div>
            </div>
            {profile.superpowers.length > 0 && (
              <div className="mt-3 flex flex-wrap gap-1">
                {profile.superpowers.map(sp => (
                  <span key={sp} className="bg-white/20 text-white text-xs px-2 py-0.5 rounded-full">{sp}</span>
                ))}
              </div>
            )}
            <p className="text-xs opacity-50 mt-3 group-hover:opacity-100 transition-opacity">点击查看个人中心 →</p>
          </button>

          {/* Progress */}
          <div className="bg-white rounded-2xl border border-slate-100 p-4 shadow-sm">
            <div className="flex justify-between items-center mb-3">
              <h3 className="font-semibold text-sm text-slate-700">成长进度</h3>
              <span className="text-xs bg-emerald-50 text-emerald-600 px-2 py-0.5 rounded-full">
                Lv.{growthProgress?.level?.level ?? profile.level} {growthProgress?.level?.name ?? profile.levelName}
              </span>
            </div>
            <div className="space-y-2.5">
              {(growthProgress?.dimensions ?? [
                { label: '方向探索', progress: profile.interest ? 1 : 0, maxProgress: 3, percentage: profile.interest ? 33 : 0 },
                { label: '作品产出', progress: profile.tasks, maxProgress: 3, percentage: Math.round((profile.tasks / 3) * 100) },
                { label: '圆桌参与', progress: profile.roundtables, maxProgress: 2, percentage: Math.round((profile.roundtables / 2) * 100) },
                { label: '面试准备', progress: 0, maxProgress: 3, percentage: 0 },
              ]).map((dim: { label: string; progress: number; maxProgress: number; percentage: number }, idx: number) => {
                const colors = ['bg-emerald-400', 'bg-amber-400', 'bg-blue-400', 'bg-purple-400'];
                return (
                  <div key={dim.label}>
                    <div className="flex justify-between text-xs text-slate-500 mb-1">
                      <span>{dim.label}</span>
                      <span>{dim.progress}/{dim.maxProgress}</span>
                    </div>
                    <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                      <div className={`h-full rounded-full transition-all duration-500 ${colors[idx] || 'bg-slate-300'}`} style={{ width: `${Math.min(dim.percentage, 100)}%` }} />
                    </div>
                  </div>
                );
              })}
            </div>
            {growthProgress && (
              <div className="mt-3 pt-2 border-t border-slate-50 flex justify-between items-center">
                <span className="text-xs text-slate-400">总进度</span>
                <span className="text-xs font-medium text-emerald-600">{growthProgress.totalProgress}/{growthProgress.maxProgress}</span>
              </div>
            )}
          </div>

          {/* Quick Actions */}
          <div className="bg-white rounded-2xl border border-slate-100 p-4 shadow-sm">
            <h3 className="font-semibold text-sm text-slate-700 mb-3">快捷入口</h3>
            <div className="grid grid-cols-2 gap-2">
              {([
                { label: '聊聊困惑', icon: '🗣', prompt: '我想聊聊最近的困惑', href: '' },
                { label: '参加圆桌', icon: '🪑', prompt: '我想看看鹅家班有没有新圆桌', href: '' },
                { label: '寄封信', icon: '💌', prompt: '我想去解忧杂货铺寄封信', href: '' },
                { label: '成长档案', icon: '📔', prompt: '我想查收我的成长档案', href: '' },
                { label: '岗位推荐', icon: '💼', prompt: '', href: '/jobs' },
                { label: '听故事', icon: '🎙️', prompt: '给我讲一个前辈的真实故事', href: '' },
              ] as { label: string; icon: string; prompt: string; href: string }[]).map(item => (
                <button
                  key={item.label}
                  onClick={() => {
                    if (item.href) {
                      router.push(item.href);
                    } else {
                      handleQuickAction(item.prompt);
                    }
                  }}
                  className="flex flex-col items-center gap-1 p-2.5 rounded-xl bg-slate-50 hover:bg-emerald-50 hover:text-emerald-600 transition-colors text-xs text-slate-600"
                >
                  <span className="text-lg">{item.icon}</span>
                  <span>{item.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Achievements */}
          <div className="bg-white rounded-2xl border border-slate-100 p-4 shadow-sm">
            <h3 className="font-semibold text-sm text-slate-700 mb-2">成就墙</h3>
            <div className="flex flex-wrap gap-2">
              {profile.achievements.map(a => (
                <span key={a} className="bg-emerald-50 text-emerald-700 text-xs px-2 py-1 rounded-lg">{a}</span>
              ))}
            </div>
          </div>
        </div>
      </aside>

      {/* ---- Sidebar Overlay (mobile) ---- */}
      {sidebarOpen && (
        <div className="fixed inset-0 bg-black/30 z-30 md:hidden" onClick={() => setSidebarOpen(false)} />
      )}

      {/* ---- Main Area ---- */}
      <main className="flex-1 flex flex-col min-w-0">
        {/* Top Nav - Module Tabs */}
        <nav className="bg-white border-b border-slate-100 px-4 py-2 flex items-center gap-1 overflow-x-auto flex-shrink-0">
          {/* Brand for mobile */}
          <div className="md:hidden flex items-center gap-2 mr-3 ml-10">
            <span className="text-lg">🐧</span>
            <span className="font-bold text-emerald-600">未来鹅</span>
          </div>
          {MODULE_TABS.map(tab => (
            <button
              key={tab.key}
              onClick={() => setActiveTab(tab.key)}
              className={`
                flex items-center gap-1.5 px-4 py-2 rounded-xl text-sm font-medium transition-all whitespace-nowrap
                ${activeTab === tab.key
                  ? 'bg-emerald-500 text-white shadow-md shadow-emerald-200'
                  : 'text-slate-500 hover:bg-slate-50 hover:text-slate-700'}
              `}
            >
              <span>{tab.icon}</span>
              <span>{tab.label}</span>
            </button>
          ))}
          {/* Status badges */}
          <div className="ml-auto flex items-center gap-2">
            {profile.grade && (
              <span className="bg-emerald-50 text-emerald-600 text-xs px-2.5 py-1 rounded-full font-medium">{profile.grade}</span>
            )}
            <span className="bg-amber-50 text-amber-600 text-xs px-2.5 py-1 rounded-full font-medium">🔥 连续1天</span>
          </div>
        </nav>

        {/* Module Content */}
        <div className="flex-1 overflow-y-auto">
          {/* ==================== GRADE MODULE ==================== */}
          {activeTab === 'grade' && (
            <div className="max-w-2xl mx-auto p-6 space-y-6">
              <div className="text-center">
                <div className="text-5xl mb-3">🐧</div>
                <h2 className="text-2xl font-bold text-slate-800 mb-2">
                  Hey，我是鹅小伴
                </h2>
                <p className="text-slate-500 leading-relaxed max-w-md mx-auto">
                  在腾讯做产品的第三年。<br />
                  不管你是刚进大学、正在迷茫，还是投简历投到怀疑自己——我都经历过。<br />
                  告诉我你的名字和年级，我们就正式开始了 😊
                </p>
              </div>

              {/* Nickname */}
              {!profile.nickname ? (
                <div className="bg-white rounded-2xl p-6 border border-slate-100 shadow-sm">
                  <h3 className="font-semibold text-slate-700 mb-3">你叫什么名字？</h3>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={nicknameInput}
                      onChange={e => setNicknameInput(e.target.value)}
                      onKeyDown={e => e.key === 'Enter' && handleNicknameSubmit()}
                      placeholder="输入你的昵称"
                      className="flex-1 border border-slate-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-400 focus:border-transparent"
                    />
                    <button
                      onClick={handleNicknameSubmit}
                      disabled={!nicknameInput.trim()}
                      className="bg-emerald-500 text-white px-6 py-2.5 rounded-xl text-sm font-medium hover:bg-emerald-600 disabled:opacity-40 transition-colors"
                    >
                      下一步
                    </button>
                  </div>
                </div>
              ) : (
                <div className="bg-emerald-50 rounded-2xl p-4 text-center">
                  <p className="text-emerald-700">欢迎你，<strong>{profile.nickname}</strong>！选一下你的年级吧 👇</p>
                </div>
              )}

              {/* Grade Selection */}
              {profile.nickname && (
                <div className="bg-white rounded-2xl p-6 border border-slate-100 shadow-sm">
                  <h3 className="font-semibold text-slate-700 mb-4">你现在读几年级？</h3>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    {GRADES.map(g => (
                      <button
                        key={g.value}
                        onClick={() => handleGradeSelect(g.value)}
                        className={`
                          flex flex-col items-center gap-1.5 p-4 rounded-2xl border-2 transition-all
                          ${profile.grade === g.value
                            ? 'border-emerald-500 bg-emerald-50 shadow-md shadow-emerald-100'
                            : 'border-slate-100 hover:border-emerald-200 hover:bg-emerald-50/50'}
                        `}
                      >
                        <span className="text-2xl">{g.icon}</span>
                        <span className="font-semibold text-sm text-slate-700">{g.label}</span>
                        <span className="text-xs text-slate-400">{g.desc}</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Quick tip */}
              {profile.grade && (
                <div className="bg-white rounded-2xl p-6 border border-slate-100 shadow-sm">
                  <div className="flex items-start gap-3">
                    <span className="text-2xl">🪿</span>
                    <div>
                      <h3 className="font-semibold text-slate-700 mb-1">小鹅有话说</h3>
                      <p className="text-sm text-slate-500 leading-relaxed">
                        {profile.grade === '大一' && '大一就开始关注职业发展，你已经比很多人领先了！不用急着定方向，咱们先了解互联网有什么，慢慢来 😊'}
                        {profile.grade === '大二' && '大二正是探索的好时机，有足够的时间试错和积累！你对什么方向比较好奇？'}
                        {profile.grade === '大三' && '大三了，到了该行动的时候了 💪 不管你是已经有方向还是在迷茫，咱们一起把接下来的路走好。'}
                        {profile.grade === '大四' && '大四冲刺期！如果你还在找工作，咱们一起制定计划。你现在是什么状态？'}
                        {profile.grade === '研一' && '研一有时间好好规划，比本科多了一些沉淀。你读研是为了学术还是为了更好的就业？'}
                        {profile.grade === '研二' && '研二了，秋招马上就来！你的目标方向定了吗？简历和项目经历准备得怎么样？'}
                        {profile.grade === '研三' && '研三，毕业就在眼前了！不管是论文还是求职，有需要我帮忙的随时说。'}
                        {profile.grade === '已毕业' && '已经步入职场了！不管是在职还是求职中，我都可以陪你聊聊。你现在最想解决什么问题？'}
                      </p>
                    </div>
                  </div>
                  <div className="mt-4 flex gap-2">
                    <button
                      onClick={() => setActiveTab('assessment')}
                      className="flex-1 bg-emerald-500 text-white py-2.5 rounded-xl text-sm font-medium hover:bg-emerald-600 transition-colors"
                    >
                      🧭 开始职业测评
                    </button>
                    <button
                      onClick={() => setActiveTab('chat')}
                      className="flex-1 bg-slate-100 text-slate-600 py-2.5 rounded-xl text-sm font-medium hover:bg-slate-200 transition-colors"
                    >
                      💬 直接聊天
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* ==================== ASSESSMENT MODULE ==================== */}
          {activeTab === 'assessment' && (
            <div className="max-w-2xl mx-auto p-6 space-y-6">
              <div className="text-center">
                <div className="text-4xl mb-2">🧭</div>
                <h2 className="text-2xl font-bold text-slate-800 mb-1">职业方向测评</h2>
                <p className="text-sm text-slate-500">回答 8 个小问题，找到最适合你的职业方向</p>
              </div>

              {!assessResult ? (
                <div className="bg-white rounded-2xl p-6 border border-slate-100 shadow-sm">
                  {/* Progress bar */}
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-sm text-slate-500">
                      第 {assessStep + 1} / {ASSESSMENT_QUESTIONS.length} 题
                    </span>
                    <span className="text-sm text-emerald-600 font-medium">
                      {Math.round(((assessStep + (Object.keys(assessAnswers).length > assessStep ? 1 : 0)) / ASSESSMENT_QUESTIONS.length) * 100)}%
                    </span>
                  </div>
                  <div className="h-2 bg-slate-100 rounded-full mb-6 overflow-hidden">
                    <div
                      className="h-full bg-emerald-400 rounded-full transition-all duration-500"
                      style={{ width: `${((assessStep + (Object.keys(assessAnswers).length > assessStep ? 1 : 0)) / ASSESSMENT_QUESTIONS.length) * 100}%` }}
                    />
                  </div>

                  {/* Current question */}
                  {assessStep < ASSESSMENT_QUESTIONS.length && (
                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold text-slate-700">
                        {ASSESSMENT_QUESTIONS[assessStep].question}
                      </h3>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        {ASSESSMENT_QUESTIONS[assessStep].options.map(opt => (
                          <button
                            key={opt.value}
                            onClick={() => handleAssessAnswer(ASSESSMENT_QUESTIONS[assessStep].id, opt.value)}
                            className={`
                              text-left p-4 rounded-xl border-2 transition-all text-sm
                              ${assessAnswers[ASSESSMENT_QUESTIONS[assessStep].id] === opt.value
                                ? 'border-emerald-500 bg-emerald-50 text-emerald-700'
                                : 'border-slate-100 hover:border-emerald-200 text-slate-600'}
                            `}
                          >
                            {opt.label}
                          </button>
                        ))}
                      </div>

                      {/* Navigation */}
                      <div className="flex justify-between pt-4">
                        <button
                          onClick={() => setAssessStep(Math.max(0, assessStep - 1))}
                          disabled={assessStep === 0}
                          className="text-sm text-slate-400 hover:text-slate-600 disabled:opacity-30 transition-colors"
                        >
                          ← 上一题
                        </button>
                        {assessStep === ASSESSMENT_QUESTIONS.length - 1 && Object.keys(assessAnswers).length === ASSESSMENT_QUESTIONS.length && (
                          <button
                            onClick={handleAssessSubmit}
                            disabled={assessLoading}
                            className="bg-emerald-500 text-white px-6 py-2 rounded-xl text-sm font-medium hover:bg-emerald-600 disabled:opacity-50 transition-colors flex items-center gap-2"
                          >
                            {assessLoading ? (
                              <>
                                <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                                分析中...
                              </>
                            ) : (
                              '查看结果 🎉'
                            )}
                          </button>
                        )}
                      </div>

                      {/* Answered dots */}
                      <div className="flex justify-center gap-1.5 pt-2">
                        {ASSESSMENT_QUESTIONS.map((q, i) => (
                          <button
                            key={q.id}
                            onClick={() => setAssessStep(i)}
                            className={`w-2.5 h-2.5 rounded-full transition-all ${
                              assessAnswers[q.id] ? 'bg-emerald-400' : 'bg-slate-200'
                            } ${i === assessStep ? 'ring-2 ring-emerald-300 ring-offset-1' : ''}`}
                          />
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                /* ---- Assessment Result ---- */
                <div className="space-y-4">
                  {/* Holland Code */}
                  <div className="bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-2xl p-6 text-white text-center">
                    <p className="text-sm opacity-80 mb-1">你的霍兰德代码</p>
                    <h2 className="text-4xl font-bold tracking-widest mb-2">{assessResult.hollandCode}</h2>
                    <p className="text-sm opacity-90">{assessResult.hollandDescription}</p>
                  </div>

                  {/* Dimensions */}
                  <div className="bg-white rounded-2xl p-6 border border-slate-100 shadow-sm">
                    <h3 className="font-semibold text-slate-700 mb-4">六维分析</h3>
                    <div className="space-y-3">
                      {assessResult.dimensions.map(dim => (
                        <div key={dim.name}>
                          <div className="flex justify-between text-sm mb-1">
                            <span className="text-slate-600">{dim.name}</span>
                            <span className="text-emerald-600 font-medium">{dim.score}%</span>
                          </div>
                          <div className="h-2.5 bg-slate-100 rounded-full overflow-hidden">
                            <div
                              className="h-full bg-emerald-400 rounded-full transition-all duration-700"
                              style={{ width: `${dim.score}%` }}
                            />
                          </div>
                          <p className="text-xs text-slate-400 mt-1">{dim.description}</p>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Recommended Roles */}
                  <div className="bg-white rounded-2xl p-6 border border-slate-100 shadow-sm">
                    <h3 className="font-semibold text-slate-700 mb-4">推荐职业方向</h3>
                    <div className="space-y-3">
                      {assessResult.recommendedRoles.map(role => (
                        <div key={role.name} className="flex items-start gap-3 p-3 rounded-xl bg-slate-50">
                          <div className="w-12 h-12 bg-emerald-100 rounded-xl flex items-center justify-center text-emerald-600 font-bold text-sm flex-shrink-0">
                            {role.match}%
                          </div>
                          <div>
                            <h4 className="font-semibold text-slate-700">{role.name}</h4>
                            <p className="text-sm text-slate-500">{role.reason}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Strengths & Suggestions */}
                  <div className="bg-white rounded-2xl p-6 border border-slate-100 shadow-sm">
                    <h3 className="font-semibold text-slate-700 mb-3">你的优势</h3>
                    <div className="flex flex-wrap gap-2 mb-4">
                      {assessResult.strengths.map(s => (
                        <span key={s} className="bg-emerald-50 text-emerald-700 text-sm px-3 py-1 rounded-full">{s}</span>
                      ))}
                    </div>
                    <h3 className="font-semibold text-slate-700 mb-2">小鹅的建议</h3>
                    <p className="text-sm text-slate-500 leading-relaxed">{assessResult.suggestions}</p>
                  </div>

                  {/* Actions */}
                  <div className="flex gap-3">
                    <button
                      onClick={resetAssessment}
                      className="flex-1 bg-slate-100 text-slate-600 py-2.5 rounded-xl text-sm font-medium hover:bg-slate-200 transition-colors"
                    >
                      重新测评
                    </button>
                    <button
                      onClick={() => setActiveTab('plan')}
                      className="flex-1 bg-emerald-500 text-white py-2.5 rounded-xl text-sm font-medium hover:bg-emerald-600 transition-colors"
                    >
                      生成成长规划 🗺️
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* ==================== CHAT MODULE ==================== */}
          {activeTab === 'chat' && (
            <div className="flex flex-col h-full">
              {/* Chat Header */}
              <div className="bg-white border-b border-slate-100 px-5 py-2.5 flex items-center gap-3 flex-shrink-0">
                <div className="w-8 h-8 bg-emerald-100 rounded-full flex items-center justify-center text-sm">🪿</div>
                <div>
                  <p className="font-semibold text-sm text-slate-700">鹅小伴</p>
                  <p className="text-xs text-emerald-500">在线 · 腾讯产品经理</p>
                </div>
              </div>

              {/* Messages */}
              <div className="flex-1 overflow-y-auto px-5 py-4 space-y-4">
                {messages.length === 0 && (
                  <div className="flex flex-col items-center justify-center h-full text-center">
                    <div className="text-5xl mb-4">🪿</div>
                    <h2 className="text-xl font-bold text-slate-700 mb-2">Hey，我是鹅小伴 🐧</h2>
                    <p className="text-sm text-slate-400 max-w-sm mb-6 leading-relaxed">
                      在腾讯做产品的第三年。不管你是刚进大学、正在迷茫，还是投简历投到怀疑自己——我都经历过。告诉我你的名字和年级吧～
                    </p>
                    <div className="grid grid-cols-2 gap-2 w-full max-w-lg">
                      {QUICK_QUESTIONS.map(q => (
                        <button
                          key={q}
                          onClick={() => sendMessage(q)}
                          className="text-left text-sm text-slate-500 bg-slate-50 hover:bg-emerald-50 hover:text-emerald-600 px-3 py-2.5 rounded-xl transition-colors truncate"
                        >
                          {q}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {messages.map(msg => (
                  <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                    <div className={`flex items-start gap-2 max-w-[85%] ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}>
                      {msg.role === 'assistant' && (
                        <div className="w-7 h-7 bg-emerald-100 rounded-full flex items-center justify-center text-xs flex-shrink-0 mt-1">🪿</div>
                      )}
                      <div className={`
                        px-4 py-3 rounded-2xl text-sm leading-relaxed
                        ${msg.role === 'user'
                          ? 'bg-emerald-500 text-white rounded-tr-sm'
                          : 'bg-white border border-slate-100 text-slate-700 shadow-sm rounded-tl-sm'}
                      `}>
                        {msg.content ? renderContent(msg.content) : (
                          <div className="flex items-center gap-1">
                            <span className="w-2 h-2 bg-emerald-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                            <span className="w-2 h-2 bg-emerald-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                            <span className="w-2 h-2 bg-emerald-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
                <div ref={chatEndRef} />
              </div>

              {/* Input */}
              <div className="bg-white border-t border-slate-100 p-4 flex-shrink-0">
                <form onSubmit={handleSubmit} className="flex items-end gap-2">
                  <textarea
                    ref={textareaRef}
                    value={input}
                    onChange={e => setInput(e.target.value)}
                    onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSubmit(e); } }}
                    placeholder="和鹅小伴聊聊..."
                    rows={1}
                    disabled={isStreaming}
                    className="flex-1 resize-none border border-slate-200 rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-400 focus:border-transparent disabled:opacity-50"
                  />
                  <button
                    type="submit"
                    disabled={!input.trim() || isStreaming}
                    className="bg-emerald-500 text-white p-2.5 rounded-xl hover:bg-emerald-600 disabled:opacity-40 transition-colors flex-shrink-0"
                    aria-label="发送"
                  >
                    <svg width="20" height="20" fill="none" stroke="currentColor" strokeWidth="2"><path d="M5 12l7-7 7 7M12 5v14" /></svg>
                  </button>
                </form>
              </div>
            </div>
          )}

          {/* ==================== GROWTH PLAN MODULE ==================== */}
          {activeTab === 'plan' && (
            <div className="max-w-2xl mx-auto p-6 space-y-6">
              <div className="text-center">
                <div className="text-4xl mb-2">🗺️</div>
                <h2 className="text-2xl font-bold text-slate-800 mb-1">成长规划</h2>
                <p className="text-sm text-slate-500">基于你的年级和方向，定制专属成长路径</p>
              </div>

              {!growthPlan ? (
                <div className="bg-white rounded-2xl p-8 border border-slate-100 shadow-sm text-center">
                  <div className="text-5xl mb-4">🪿</div>
                  <h3 className="font-semibold text-slate-700 mb-2">让我为你制定成长规划</h3>
                  <p className="text-sm text-slate-400 mb-6">
                    {profile.grade
                      ? `基于你的${profile.grade}阶段${profile.interest ? `和${profile.interest}方向` : ''}，我会为你定制一份成长路线`
                      : '请先在「年级选择」中设置你的基本信息'}
                  </p>
                  <button
                    onClick={generateGrowthPlan}
                    disabled={planLoading || !profile.grade}
                    className="bg-emerald-500 text-white px-8 py-3 rounded-xl font-medium hover:bg-emerald-600 disabled:opacity-50 transition-colors inline-flex items-center gap-2"
                  >
                    {planLoading ? (
                      <>
                        <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                        正在生成规划...
                      </>
                    ) : (
                      '生成我的成长规划 🚀'
                    )}
                  </button>
                </div>
              ) : (
                <div className="space-y-4">
                  {/* Summary */}
                  <div className="bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-2xl p-5 text-white">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-xs bg-white/20 px-2 py-0.5 rounded-full">{growthPlan.currentStage}</span>
                    </div>
                    <p className="text-sm leading-relaxed">{growthPlan.summary}</p>
                  </div>

                  {/* Milestones */}
                  <div className="bg-white rounded-2xl p-6 border border-slate-100 shadow-sm">
                    <h3 className="font-semibold text-slate-700 mb-4">成长里程碑</h3>
                    <div className="space-y-0">
                      {growthPlan.milestones.map((ms, idx) => (
                        <div key={ms.id} className="flex gap-3">
                          <div className="flex flex-col items-center">
                            <div className={`
                              w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold
                              ${ms.status === 'completed' ? 'bg-emerald-500 text-white' :
                                ms.status === 'in_progress' ? 'bg-amber-100 text-amber-600 ring-2 ring-amber-300' :
                                'bg-slate-100 text-slate-400'}
                            `}>
                              {ms.status === 'completed' ? '✓' : idx + 1}
                            </div>
                            {idx < growthPlan.milestones.length - 1 && (
                              <div className={`w-0.5 h-8 ${ms.status === 'completed' ? 'bg-emerald-300' : 'bg-slate-200'}`} />
                            )}
                          </div>
                          <div className="pb-4">
                            <h4 className="font-medium text-sm text-slate-700">{ms.title}</h4>
                            <p className="text-xs text-slate-400 mt-0.5">{ms.description}</p>
                            <span className="text-xs text-emerald-500 mt-1 inline-block">{ms.duration}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Weekly Tasks */}
                  <div className="bg-white rounded-2xl p-6 border border-slate-100 shadow-sm">
                    <h3 className="font-semibold text-slate-700 mb-4">周度任务</h3>
                    <div className="space-y-4">
                      {growthPlan.weeklyTasks.map((week, idx) => (
                        <div key={idx}>
                          <h4 className="text-sm font-medium text-emerald-600 mb-2">{week.week}</h4>
                          <div className="space-y-2">
                            {week.tasks.map((task, ti) => (
                              <div key={ti} className="flex items-start gap-2 text-sm text-slate-600">
                                <span className="w-5 h-5 border-2 border-slate-200 rounded flex-shrink-0 mt-0.5" />
                                <span>{task}</span>
                              </div>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Key Advice */}
                  <div className="bg-amber-50 rounded-2xl p-5 border border-amber-100">
                    <div className="flex items-start gap-3">
                      <span className="text-2xl">💡</span>
                      <div>
                        <h3 className="font-semibold text-amber-800 mb-1">核心建议</h3>
                        <p className="text-sm text-amber-700 leading-relaxed">{growthPlan.keyAdvice}</p>
                      </div>
                    </div>
                  </div>

                  {/* Resources */}
                  {growthPlan.resources.length > 0 && (
                    <div className="bg-white rounded-2xl p-6 border border-slate-100 shadow-sm">
                      <h3 className="font-semibold text-slate-700 mb-3">推荐资源</h3>
                      <div className="space-y-2">
                        {growthPlan.resources.map((r, idx) => (
                          <div key={idx} className="flex items-center gap-3 p-2 rounded-lg bg-slate-50">
                            <span className="text-lg">{r.type === 'book' ? '📖' : r.type === 'website' ? '🌐' : '📎'}</span>
                            <div>
                              <p className="text-sm font-medium text-slate-700">{r.name}</p>
                              <p className="text-xs text-slate-400">{r.reason}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Actions */}
                  <div className="flex gap-3">
                    <button
                      onClick={() => setGrowthPlan(null)}
                      className="flex-1 bg-slate-100 text-slate-600 py-2.5 rounded-xl text-sm font-medium hover:bg-slate-200 transition-colors"
                    >
                      重新生成
                    </button>
                    <button
                      onClick={() => setActiveTab('chat')}
                      className="flex-1 bg-emerald-500 text-white py-2.5 rounded-xl text-sm font-medium hover:bg-emerald-600 transition-colors"
                    >
                      和小鹅聊聊规划 💬
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
