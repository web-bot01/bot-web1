---
AIGC:
    Label: "1"
    ContentProducer: 001191110102MACQD9K64018705
    ProduceID: 1729954525759828_0/project_7649034774379577634-files/feishu-auth-guide.md
    ReservedCode1: ""
    ContentPropagator: 001191110102MACQD9K64028705
    PropagateID: 1729954525759828#1781164156836
    ReservedCode2: ""
---
# 鹅小伴 · 飞书应用授权与多维表创建指南

## 问题说明

当前飞书 CLI 授权失败，错误：`App ID is required.`

原因：扣子平台的飞书渠道尚未绑定应用凭证。需要先创建飞书应用并获取 App ID 和 App Secret。

---

## 步骤一：创建飞书应用

1. 登录 [飞书开放平台](https://open.feishu.cn/app)
2. 点击「创建企业自建应用」
3. 应用名称：`未来鹅`
4. 应用描述：`大学生职业成长AI陪伴 - 数据存储`
5. 创建完成后，进入应用详情页
6. 记录 **App ID** 和 **App Secret**

## 步骤二：配置应用权限

在应用详情页 → 权限管理，开通以下权限：

| 权限 | 权限标识 | 用途 |
|------|----------|------|
| 查看多维表格 | `bitable:app:readonly` | 读取数据 |
| 编辑多维表格 | `bitable:app` | 写入数据 |
| 获取多维表格元数据 | `bitable:app:readonly` | 查询表结构 |

## 步骤三：在扣子平台绑定飞书渠道

1. 登录扣子平台
2. 进入项目设置 → 渠道 → 飞书
3. 添加飞书应用
4. 输入 App ID 和 App Secret
5. 保存

## 步骤四：验证授权

绑定后，重新在扣子对话中执行飞书 CLI 命令验证：
```bash
lark base list
```

如果返回应用列表，说明授权成功。

## 步骤五：创建多维表

授权成功后，按照「鹅小伴知识库-飞书多维表数据库设计.md」中的完整步骤创建 Base 和 4 张表。

快捷操作：
1. 读取数据库设计文档中的 JSON 配置
2. 使用 `lark base create` 创建 Base
3. 使用 `lark base table create` 逐个创建 4 张表
4. 使用 `lark base field create` 为每张表添加字段

---

## 备选方案：手动创建

如果 CLI 授权仍有问题，可以直接在飞书中手动创建：

1. 打开 [飞书多维表格](https://feishu.cn/base)
2. 新建 Base，名称：`未来鹅-数据库`
3. 按照数据库设计文档手动添加表和字段
4. 创建完成后，在 Coze Bot 中通过「飞书多维表插件」连接该 Base

这种方式同样有效，只是需要手动建表。

---

> 本内容由 Coze AI 生成，请遵循相关法律法规及《人工智能生成合成内容标识办法》使用与传播。
