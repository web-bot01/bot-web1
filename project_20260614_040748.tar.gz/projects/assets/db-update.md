---
AIGC:
    Label: "1"
    ContentProducer: 001191110102MACQD9K64018705
    ProduceID: 1729954525759828_0/project_7649034774379577634-files/db-update.md
    ReservedCode1: ""
    ContentPropagator: 001191110102MACQD9K64028705
    PropagateID: 1729954525759828#1781164153102
    ReservedCode2: ""
---
# 鹅小伴 · 飞书多维表 — 实际创建结果

## ✅ 已完成创建

**Base 名称**：未来鹅 · 数据库  
**Base Token**：`Xod4bNndbaWgvHsqthzcdBWbnwf`  
**访问链接**：https://acnylttj9cn8.feishu.cn/base/Xod4bNndbaWgvHsqthzcdBWbnwf

### 数据表 ID

| 表名 | Table ID |
|------|----------|
| 用户成长档案 | tblwOARUPUWTPMmC |
| 鹅家班圆桌记录 | tblOnuhnhSNVJnUL |
| 解忧杂货铺 | tblquZZxTaTqBZ6x |
| 前辈经验库 | tblYKYifQECuSNc8 |

### 预填数据

- ✅ 前辈经验库已写入7条数据（山风/小雨/阿泽/阿澈/小七/陆学长/小北）

---

## ⚠️ 需手动修改：多选字段

lark-cli 创建多选字段时自动降级为单选，需在飞书界面手动改为多选：

| 表名 | 字段名 | 当前类型 | 应改为 |
|------|--------|----------|--------|
| 用户成长档案 | 已解锁成就 | 单选 | **多选** |
| 用户成长档案 | 职业超能力标签 | 单选 | **多选** |
| 鹅家班圆桌记录 | 困境标签 | 单选 | **多选** |
| 前辈经验库 | 困境标签 | 单选 | **多选** |

**修改方法**：打开飞书多维表格 → 点击字段名 → 修改字段类型为「多选」→ 保存

---

## Coze Bot 中连接多维表

1. 在 Coze Bot 编辑页 → 插件 → 搜索「飞书多维表」
2. 配置 Base Token：`Xod4bNndbaWgvHsqthzcdBWbnwf`
3. 选择对应表进行读写操作

---

> 本内容由 Coze AI 生成，请遵循相关法律法规及《人工智能生成合成内容标识办法》使用与传播。
