---
AIGC:
    Label: "1"
    ContentProducer: 001191110102MACQD9K64018705
    ProduceID: 1729954525759828_0/project_7649034774379577634-files/vercel-deploy.md
    ReservedCode1: ""
    ContentPropagator: 001191110102MACQD9K64028705
    PropagateID: 1729954525759828#1781164171014
    ReservedCode2: ""
---
# 未来鹅 · Vercel 部署指南

## 前置准备
1. 注册 [GitHub](https://github.com) 账号
2. 注册 [Vercel](https://vercel.com) 账号（可用 GitHub 登录）
3. 已获取 Coze Bot 的 Web SDK 嵌入代码

## 步骤一：创建 GitHub 仓库

1. 登录 GitHub → New Repository
2. 仓库名：`future-goose`
3. 设为 Public
4. 不勾选 README / .gitignore / License
5. 点击 Create Repository

## 步骤二：准备项目文件

在本地创建以下目录结构：
```
future-goose/
├── index.html          ← 前端页面（项目中的「未来鹅-前端页面.html」）
├── vercel.json         ← Vercel 配置
└── README.md           ← 项目说明
```

### vercel.json 内容
```json
{
  "rewrites": [
    { "source": "/(.*)", "destination": "/index.html" }
  ]
}
```

### 修改 index.html 中的 Coze 嵌入代码

找到 HTML 中的聊天嵌入区域，替换为你的 Coze Web SDK 代码：

```html
<!-- 替换此区域 -->
<div id="coze-chat-area">
  <!-- Coze Web SDK 代码粘贴到这里 -->
  <script src="https://lf-cdn-tos.bytescm.com/obj/static/xverse_se/xxx/sdk.js"></script>
  <script>
    new CozeWebSDK.WebChat({
      bot_id: '你的Bot ID',
      // ... 其他配置
    });
  </script>
</div>
```

## 步骤三：推送到 GitHub

```bash
cd future-goose
git init
git add .
git commit -m "init: 未来鹅前端页面"
git remote add origin https://github.com/你的用户名/future-goose.git
git push -u origin main
```

## 步骤四：Vercel 一键部署

1. 登录 [Vercel](https://vercel.com)
2. 点击「Add New Project」
3. 选择刚创建的 `future-goose` 仓库
4. Framework Preset 选择「Other」
5. 点击「Deploy」
6. 等待部署完成（通常30秒）
7. 获得公网链接：`https://future-goose-xxx.vercel.app`

## 步骤五：自定义域名（可选）

1. Vercel Dashboard → 项目 → Settings → Domains
2. 添加你的自定义域名
3. 按提示配置 DNS 记录

## 更新页面

修改代码后：
```bash
git add .
git commit -m "update: 更新说明"
git push
```
Vercel 会自动检测并重新部署（约30秒生效）。

## URL 参数说明

页面支持通过 URL 参数定制身份卡：

| 参数 | 说明 | 示例 |
|------|------|------|
| name | 用户昵称 | `?name=小明` |
| grade | 年级 | `&grade=大三` |
| interest | 职业兴趣 | `&interest=产品经理` |

完整示例：`https://future-goose-xxx.vercel.app/?name=小明&grade=大三&interest=产品经理`

---

> 本内容由 Coze AI 生成，请遵循相关法律法规及《人工智能生成合成内容标识办法》使用与传播。
