# 未来鹅 - AI 职业成长陪伴

## 项目概览

面向大学生的 AI 职业成长陪伴智能体"鹅小伴"，提供 AI 对话、职业测评、成长规划、岗位推荐等功能。绿色主题双栏布局，企鹅品牌元素。

## 版本技术栈

- **Framework**: Next.js 16 (App Router)
- **Core**: React 19
- **Language**: TypeScript 5
- **UI 组件**: shadcn/ui (基于 Radix UI)
- **Styling**: Tailwind CSS 4
- **AI SDK**: coze-coding-dev-sdk (LLMClient + Config + HeaderUtils)
- **Auth**: Supabase Auth (邮箱登录，环境变量配置时启用)
- **Database**: Supabase PostgreSQL (user_profiles 表)

## 目录结构

```
├── public/                 # 静态资源
├── src/
│   ├── app/                # 页面路由与布局
│   │   ├── api/            # API 路由
│   │   │   ├── chat/route.ts         # 流式 AI 对话（核心）
│   │   │   ├── assessment/route.ts   # 职业测评（霍兰德模型）
│   │   │   ├── growth-plan/route.ts  # 成长规划
│   │   │   ├── job-recommend/route.ts # 岗位推荐
│   │   │   ├── profile/route.ts      # 用户资料（需 Supabase）
│   │   │   └── supabase-config/route.ts # Supabase 配置查询
│   │   ├── login/page.tsx  # 登录/注册页
│   │   ├── profile/page.tsx # 个人中心
│   │   ├── jobs/page.tsx   # 岗位推荐页
│   │   └── page.tsx        # 首页（渲染 ChatPage 组件）
│   ├── components/
│   │   ├── chat-page.tsx   # 核心前端组件（4模块Tab + 双栏布局 + Onboarding）
│   │   └── ui/             # shadcn/ui 组件库
│   ├── hooks/              # 自定义 Hooks
│   ├── lib/
│   │   ├── supabase-browser.ts # 浏览器端 Supabase 客户端
│   │   └── utils.ts        # 通用工具函数
│   └── storage/database/
│       ├── supabase-server.ts  # 服务端 Supabase 客户端
│       └── shared/schema.ts    # 数据库表定义
├── next.config.ts
├── package.json
└── tsconfig.json
```

## 构建和测试命令

- 安装依赖: `pnpm install`
- 开发启动: `pnpm run dev` (端口 5000)
- 构建检查: `pnpm ts-check`
- Lint 检查: `pnpm lint --quiet`
- 生产构建: `pnpm run build`
- 生产启动: `pnpm run start`

## 核心功能

### AI 对话 (chat/route.ts)
- 使用 `LLMClient` + `client.stream()` 实现流式输出
- 注入完整鹅小伴人设提示词 + 知识库
- SSE 协议，后端 ReadableStream + 前端 Reader 打字机效果
- 4 大交互场景：圆桌讨论 / 解忧杂货铺 / 成长档案 / 自由对话
- 情绪识别 + 主动关怀 + 三选一引导 + 成长阶段剧情线

### 职业测评 (assessment/route.ts)
- 霍兰德模型 6 维评分
- LLM 流式收集后返回 JSON

### 成长规划 (growth-plan/route.ts)
- 基于年级/兴趣/阶段生成里程碑 + 周任务 + 资源

### 岗位推荐 (job-recommend/route.ts)
- LLM 基于用户画像 + 腾讯事业群知识推荐岗位
- 返回匹配分数/要求/课程/成长路径

### Supabase 降级策略
- `supabase-browser.ts`: 环境变量未配置时返回 `null`
- `isSupabaseConfigured()`: 检查配置状态
- 各页面通过 `configured` 标志显示降级 UI
- 登录/个人中心在 Supabase 未配置时显示友好提示

## 代码风格指南

- TypeScript strict 模式，禁止隐式 any
- 函数参数、返回值、事件对象必须标注类型
- LLM SDK 用法: `new LLMClient({baseUrl: Config.baseUrl, headers: HeaderUtils.simpleAuth({apiKey: Config.apiKey})})` + `client.stream({model, messages})`
- 严禁 Hydration 错误: 动态内容使用 'use client' + useEffect + useState
- 严禁 head 标签: 使用 metadata / globals.css @import / ReactDOM.preconnect
- 仅使用 pnpm 包管理器

## 设计规范

参见 DESIGN.md：清新翡翠绿主色、双栏布局、企鹅品牌元素、温暖陪伴风格
